# Student Management System - Backend
学生管理系统 - 后端 (Spring Boot)

## 项目说明 / Project Description
这是学生管理系统的后端项目，使用 Spring Boot 开发。
This is the backend project of Student Management System, developed with Spring Boot.

## 技术栈 / Tech Stack
- Java 21
- Spring Boot 3.5.0
- Spring Data JPA
- H2 Database (内存数据库)
- MySQL 支持 (可选)

## 运行方式 / How to Run
Windows: 双击 `启动.bat` / Double-click `启动.bat`
或者用 Maven: `mvnw.cmd spring-boot:run`

## 访问地址 / Access URL
- API地址: http://localhost:8081

## 数据库 / Database
默认使用 H2 内存数据库，无需额外配置。
默认端口: 8081
