package com.example.sms.server.service;

import com.example.sms.server.dto.StudentDevelopmentRecordRequest;
import com.example.sms.server.dto.StudentDevelopmentRecordResponse;
import com.example.sms.server.dto.StudentDevelopmentRecordReviewRequest;
import com.example.sms.server.exception.BusinessException;
import com.example.sms.server.exception.ResourceNotFoundException;
import com.example.sms.server.model.ApprovalStatus;
import com.example.sms.server.model.Student;
import com.example.sms.server.model.StudentDevelopmentRecord;
import com.example.sms.server.repository.StudentDevelopmentRecordRepository;
import com.example.sms.server.repository.StudentRepository;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class StudentDevelopmentRecordService {

    private final StudentDevelopmentRecordRepository recordRepository;
    private final StudentRepository studentRepository;

    public StudentDevelopmentRecordService(StudentDevelopmentRecordRepository recordRepository, StudentRepository studentRepository) {
        this.recordRepository = recordRepository;
        this.studentRepository = studentRepository;
    }

    @Transactional(readOnly = true)
    public List<StudentDevelopmentRecordResponse> listAll() {
        return recordRepository.findAll(Sort.by(Sort.Order.desc("startDate"), Sort.Order.desc("createdAt"))).stream()
                .map(StudentDevelopmentRecordResponse::fromEntity)
                .toList();
    }

    public StudentDevelopmentRecordResponse create(StudentDevelopmentRecordRequest request) {
        StudentDevelopmentRecord record = new StudentDevelopmentRecord();
        applyRequest(record, request);
        return StudentDevelopmentRecordResponse.fromEntity(recordRepository.save(record));
    }

    public StudentDevelopmentRecordResponse update(Long id, StudentDevelopmentRecordRequest request) {
        StudentDevelopmentRecord record = recordRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("成长档案记录不存在"));
        applyRequest(record, request);
        return StudentDevelopmentRecordResponse.fromEntity(recordRepository.save(record));
    }

    public StudentDevelopmentRecordResponse review(Long id, StudentDevelopmentRecordReviewRequest request) {
        if (request.status() != ApprovalStatus.APPROVED && request.status() != ApprovalStatus.REJECTED) {
            throw new BusinessException("审批结果只能是通过或驳回");
        }

        StudentDevelopmentRecord record = recordRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("成长档案记录不存在"));

        record.setStatus(request.status());
        record.setReviewerName(request.reviewerName().trim());
        record.setReviewComment(trimToNull(request.reviewComment()));
        record.setReviewedAt(LocalDateTime.now());

        return StudentDevelopmentRecordResponse.fromEntity(recordRepository.save(record));
    }

    public void delete(Long id) {
        StudentDevelopmentRecord record = recordRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("成长档案记录不存在"));
        recordRepository.delete(record);
    }

    private void applyRequest(StudentDevelopmentRecord record, StudentDevelopmentRecordRequest request) {
        if (request.endDate() != null && request.endDate().isBefore(request.startDate())) {
            throw new BusinessException("结束日期不能早于开始日期");
        }
        if (request.status() == ApprovalStatus.APPROVED || request.status() == ApprovalStatus.REJECTED) {
            throw new BusinessException("保存记录时状态只能为草稿或待审批");
        }

        Student student = studentRepository.findById(request.studentId())
                .orElseThrow(() -> new ResourceNotFoundException("学生不存在"));

        record.setStudent(student);
        record.setCategory(request.category());
        record.setTitle(request.title().trim());
        record.setDescription(trimToNull(request.description()));
        record.setOrganizer(trimToNull(request.organizer()));
        record.setLocation(trimToNull(request.location()));
        record.setStartDate(request.startDate());
        record.setEndDate(request.endDate());
        record.setScore(request.score());
        record.setAmount(request.amount());
        record.setStatus(request.status());

        if (request.status() == ApprovalStatus.DRAFT) {
            record.setReviewerName(null);
            record.setReviewComment(null);
            record.setReviewedAt(null);
        }
    }

    private String trimToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }
}
