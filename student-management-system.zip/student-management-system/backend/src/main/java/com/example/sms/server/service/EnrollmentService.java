package com.example.sms.server.service;

import com.example.sms.server.dto.EnrollmentRequest;
import com.example.sms.server.dto.EnrollmentResponse;
import com.example.sms.server.exception.BusinessException;
import com.example.sms.server.exception.ResourceNotFoundException;
import com.example.sms.server.model.Course;
import com.example.sms.server.model.Enrollment;
import com.example.sms.server.model.Student;
import com.example.sms.server.repository.CourseRepository;
import com.example.sms.server.repository.EnrollmentRepository;
import com.example.sms.server.repository.StudentRepository;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class EnrollmentService {

    private final EnrollmentRepository enrollmentRepository;
    private final StudentRepository studentRepository;
    private final CourseRepository courseRepository;

    public EnrollmentService(EnrollmentRepository enrollmentRepository, StudentRepository studentRepository, CourseRepository courseRepository) {
        this.enrollmentRepository = enrollmentRepository;
        this.studentRepository = studentRepository;
        this.courseRepository = courseRepository;
    }

    @Transactional(readOnly = true)
    public List<EnrollmentResponse> listEnrollments() {
        return enrollmentRepository.findAll(Sort.by(Sort.Direction.DESC, "createdAt")).stream()
                .map(EnrollmentResponse::fromEntity)
                .toList();
    }

    public EnrollmentResponse create(EnrollmentRequest request) {
        if (enrollmentRepository.existsByStudentIdAndCourseId(request.studentId(), request.courseId())) {
            throw new BusinessException("该学生已存在相同课程的选课记录");
        }
        Enrollment enrollment = new Enrollment();
        applyRequest(enrollment, request);
        return EnrollmentResponse.fromEntity(enrollmentRepository.save(enrollment));
    }

    public EnrollmentResponse update(Long id, EnrollmentRequest request) {
        Enrollment enrollment = enrollmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("选课记录不存在"));

        if (enrollmentRepository.existsByStudentIdAndCourseIdAndIdNot(request.studentId(), request.courseId(), id)) {
            throw new BusinessException("该学生已存在相同课程的选课记录");
        }

        applyRequest(enrollment, request);
        return EnrollmentResponse.fromEntity(enrollmentRepository.save(enrollment));
    }

    public void delete(Long id) {
        Enrollment enrollment = enrollmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("选课记录不存在"));
        enrollmentRepository.delete(enrollment);
    }

    private void applyRequest(Enrollment enrollment, EnrollmentRequest request) {
        Student student = studentRepository.findById(request.studentId())
                .orElseThrow(() -> new ResourceNotFoundException("学生不存在"));
        Course course = courseRepository.findById(request.courseId())
                .orElseThrow(() -> new ResourceNotFoundException("课程不存在"));

        enrollment.setStudent(student);
        enrollment.setCourse(course);
        enrollment.setAttendanceRate(request.attendanceRate());
        enrollment.setHomeworkScore(request.homeworkScore());
        enrollment.setFinalScore(request.finalScore());
        enrollment.setTotalScore(request.totalScore());
        enrollment.setAbsentCount(request.absentCount());
    }
}
