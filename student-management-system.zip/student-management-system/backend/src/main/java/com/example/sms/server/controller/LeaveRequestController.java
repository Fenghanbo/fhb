package com.example.sms.server.controller;

import com.example.sms.server.dto.LeaveRequestCreateRequest;
import com.example.sms.server.dto.LeaveRequestResponse;
import com.example.sms.server.dto.LeaveRequestReviewRequest;
import com.example.sms.server.service.LeaveRequestService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/leaves")
public class LeaveRequestController {

    private final LeaveRequestService leaveRequestService;

    public LeaveRequestController(LeaveRequestService leaveRequestService) {
        this.leaveRequestService = leaveRequestService;
    }

    @GetMapping
    public List<LeaveRequestResponse> listLeaveRequests() {
        return leaveRequestService.listAll();
    }

    @PostMapping
    public LeaveRequestResponse createLeaveRequest(@Valid @RequestBody LeaveRequestCreateRequest request) {
        return leaveRequestService.create(request);
    }

    @PutMapping("/{id}/review")
    public LeaveRequestResponse reviewLeave(@PathVariable Long id, @Valid @RequestBody LeaveRequestReviewRequest request) {
        return leaveRequestService.review(id, request);
    }
}
