package com.example.sms.server.dto;

import jakarta.validation.constraints.NotBlank;

public record RoleRequest(
        @NotBlank(message = "角色名称不能为空") String name,
        @NotBlank(message = "角色描述不能为空") String description,
        String permissions
) {
}
