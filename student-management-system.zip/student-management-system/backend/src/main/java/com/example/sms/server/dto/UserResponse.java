package com.example.sms.server.dto;

import com.example.sms.server.model.AppUser;

public record UserResponse(
        Long id,
        String username,
        String fullName,
        String email,
        String phone,
        boolean enabled,
        Long roleId,
        String roleName
) {
    public static UserResponse fromEntity(AppUser user) {
        return new UserResponse(
                user.getId(),
                user.getUsername(),
                user.getFullName(),
                user.getEmail(),
                user.getPhone(),
                user.isEnabled(),
                user.getRole().getId(),
                user.getRole().getName()
        );
    }
}
