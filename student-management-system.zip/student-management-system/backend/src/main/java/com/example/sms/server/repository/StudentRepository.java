package com.example.sms.server.repository;

import com.example.sms.server.model.Gender;
import com.example.sms.server.model.Student;
import com.example.sms.server.model.StudentStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository extends JpaRepository<Student, Long> {

    boolean existsByStudentNo(String studentNo);

    boolean existsByStudentNoAndIdNot(String studentNo, Long id);

    long countByGender(Gender gender);

    long countByStatus(StudentStatus status);

    Page<Student> findByStudentNoContainingOrNameContainingOrPhoneContaining(String studentNo, String name, String phone, Pageable pageable);
}
