package com.example.sms.server.service;

import com.example.sms.server.dto.LeaveRequestCreateRequest;
import com.example.sms.server.dto.LeaveRequestResponse;
import com.example.sms.server.dto.LeaveRequestReviewRequest;
import com.example.sms.server.exception.BusinessException;
import com.example.sms.server.exception.ResourceNotFoundException;
import com.example.sms.server.model.LeaveRequest;
import com.example.sms.server.model.LeaveStatus;
import com.example.sms.server.model.Student;
import com.example.sms.server.repository.LeaveRequestRepository;
import com.example.sms.server.repository.StudentRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class LeaveRequestService {

    private final LeaveRequestRepository leaveRequestRepository;
    private final StudentRepository studentRepository;

    public LeaveRequestService(LeaveRequestRepository leaveRequestRepository, StudentRepository studentRepository) {
        this.leaveRequestRepository = leaveRequestRepository;
        this.studentRepository = studentRepository;
    }

    public List<LeaveRequestResponse> listAll() {
        return leaveRequestRepository.findAllByOrderBySubmittedAtDesc().stream()
                .map(LeaveRequestResponse::fromEntity)
                .toList();
    }

    public LeaveRequestResponse create(LeaveRequestCreateRequest request) {
        if (request.endDate().isBefore(request.startDate())) {
            throw new BusinessException("结束日期不能早于开始日期");
        }

        Student student = studentRepository.findById(request.studentId())
                .orElseThrow(() -> new ResourceNotFoundException("学生不存在"));

        LeaveRequest leaveRequest = new LeaveRequest();
        leaveRequest.setStudent(student);
        leaveRequest.setReason(request.reason().trim());
        leaveRequest.setDestination(trimToNull(request.destination()));
        leaveRequest.setContactPhone(request.contactPhone().trim());
        leaveRequest.setStartDate(request.startDate());
        leaveRequest.setEndDate(request.endDate());
        leaveRequest.setStatus(LeaveStatus.PENDING);
        leaveRequest.setSubmitterName(request.submitterName().trim());
        leaveRequest.setSubmittedAt(LocalDateTime.now());

        return LeaveRequestResponse.fromEntity(leaveRequestRepository.save(leaveRequest));
    }

    public LeaveRequestResponse review(Long id, LeaveRequestReviewRequest request) {
        if (request.status() == LeaveStatus.PENDING) {
            throw new BusinessException("审批结果不能为待审批");
        }

        LeaveRequest leaveRequest = leaveRequestRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("请假记录不存在"));

        if (leaveRequest.getStatus() != LeaveStatus.PENDING) {
            throw new BusinessException("该请假记录已经审批过");
        }

        leaveRequest.setStatus(request.status());
        leaveRequest.setReviewerName(request.reviewerName().trim());
        leaveRequest.setReviewComment(trimToNull(request.reviewComment()));
        leaveRequest.setReviewedAt(LocalDateTime.now());

        return LeaveRequestResponse.fromEntity(leaveRequestRepository.save(leaveRequest));
    }

    private String trimToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }
}
