package com.example.sms.server.dto;

import com.example.sms.server.model.LeaveRequest;

import java.time.LocalDate;
import java.time.LocalDateTime;

public record LeaveRequestResponse(
        Long id,
        Long studentId,
        String studentNo,
        String studentName,
        String reason,
        String destination,
        String contactPhone,
        LocalDate startDate,
        LocalDate endDate,
        String status,
        String submitterName,
        String reviewerName,
        String reviewComment,
        LocalDateTime submittedAt,
        LocalDateTime reviewedAt
) {
    public static LeaveRequestResponse fromEntity(LeaveRequest leaveRequest) {
        return new LeaveRequestResponse(
                leaveRequest.getId(),
                leaveRequest.getStudent().getId(),
                leaveRequest.getStudent().getStudentNo(),
                leaveRequest.getStudent().getName(),
                leaveRequest.getReason(),
                leaveRequest.getDestination(),
                leaveRequest.getContactPhone(),
                leaveRequest.getStartDate(),
                leaveRequest.getEndDate(),
                leaveRequest.getStatus().name(),
                leaveRequest.getSubmitterName(),
                leaveRequest.getReviewerName(),
                leaveRequest.getReviewComment(),
                leaveRequest.getSubmittedAt(),
                leaveRequest.getReviewedAt()
        );
    }
}
