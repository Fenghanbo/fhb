package com.example.sms.server.dto;

import com.example.sms.server.model.LeaveStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record LeaveRequestReviewRequest(
        @NotNull(message = "审批结果不能为空") LeaveStatus status,
        @NotBlank(message = "审批人不能为空") String reviewerName,
        String reviewComment
) {
}
