package com.example.sms.server.dto;

import com.example.sms.server.model.ApprovalStatus;
import com.example.sms.server.model.DevelopmentCategory;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.time.LocalDate;

public record StudentDevelopmentRecordRequest(
        @NotNull(message = "学生不能为空") Long studentId,
        @NotNull(message = "记录类型不能为空") DevelopmentCategory category,
        @NotBlank(message = "主题不能为空") String title,
        String description,
        String organizer,
        String location,
        @NotNull(message = "开始日期不能为空") LocalDate startDate,
        LocalDate endDate,
        @DecimalMin(value = "0.0", message = "分值不能为负数") BigDecimal score,
        @DecimalMin(value = "0.0", message = "金额不能为负数") BigDecimal amount,
        @NotNull(message = "记录状态不能为空") ApprovalStatus status
) {
}
