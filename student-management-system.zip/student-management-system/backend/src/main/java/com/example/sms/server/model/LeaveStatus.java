package com.example.sms.server.model;

public enum LeaveStatus {
    PENDING,
    APPROVED,
    REJECTED
}
