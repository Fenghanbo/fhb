package com.example.sms.server.service;

import com.example.sms.server.dto.LoginRequest;
import com.example.sms.server.dto.LoginResponse;
import com.example.sms.server.exception.BusinessException;
import com.example.sms.server.model.AppUser;
import com.example.sms.server.repository.AppUserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    private final AppUserRepository appUserRepository;
    private final PasswordEncoder passwordEncoder;

    public AuthService(AppUserRepository appUserRepository, PasswordEncoder passwordEncoder) {
        this.appUserRepository = appUserRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public LoginResponse login(LoginRequest request) {
        AppUser user = appUserRepository.findByUsernameIgnoreCase(request.username())
                .orElseThrow(() -> new BusinessException("用户名或密码错误"));

        if (!user.isEnabled()) {
            throw new BusinessException("当前账号已被禁用");
        }
        if (!passwordEncoder.matches(request.password(), user.getPasswordHash())) {
            throw new BusinessException("用户名或密码错误");
        }

        return new LoginResponse(
                user.getId(),
                user.getUsername(),
                user.getFullName(),
                user.getRole().getName(),
                user.isEnabled()
        );
    }
}
