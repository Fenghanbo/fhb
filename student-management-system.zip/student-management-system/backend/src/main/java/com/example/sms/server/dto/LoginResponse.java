package com.example.sms.server.dto;

public record LoginResponse(
        Long userId,
        String username,
        String fullName,
        String roleName,
        boolean enabled
) {
}
