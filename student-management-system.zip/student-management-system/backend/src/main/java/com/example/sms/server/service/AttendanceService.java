package com.example.sms.server.service;

import com.example.sms.server.dto.AttendanceRequest;
import com.example.sms.server.dto.AttendanceResponse;
import com.example.sms.server.exception.BusinessException;
import com.example.sms.server.exception.ResourceNotFoundException;
import com.example.sms.server.model.Attendance;
import com.example.sms.server.model.AttendanceStatus;
import com.example.sms.server.model.Course;
import com.example.sms.server.model.Student;
import com.example.sms.server.repository.AttendanceRepository;
import com.example.sms.server.repository.CourseRepository;
import com.example.sms.server.repository.StudentRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class AttendanceService {

    private final AttendanceRepository attendanceRepository;
    private final StudentRepository studentRepository;
    private final CourseRepository courseRepository;

    public AttendanceService(AttendanceRepository attendanceRepository, StudentRepository studentRepository, CourseRepository courseRepository) {
        this.attendanceRepository = attendanceRepository;
        this.studentRepository = studentRepository;
        this.courseRepository = courseRepository;
    }

    @Transactional(readOnly = true)
    public List<AttendanceResponse> listAttendances() {
        return attendanceRepository.findAll(Sort.by(Sort.Direction.DESC, "attendanceDate")).stream()
                .map(AttendanceResponse::fromEntity)
                .toList();
    }

    @Transactional(readOnly = true)
    public Page<AttendanceResponse> listAttendancesPage(int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "attendanceDate"));
        return attendanceRepository.findAll(pageable)
                .map(AttendanceResponse::fromEntity);
    }

    public AttendanceResponse create(AttendanceRequest request) {
        if (attendanceRepository.existsByStudentIdAndCourseIdAndAttendanceDate(request.studentId(), request.courseId(), request.attendanceDate())) {
            throw new BusinessException("该学生在该日期的课程考勤记录已存在");
        }
        Attendance attendance = new Attendance();
        applyRequest(attendance, request);
        return AttendanceResponse.fromEntity(attendanceRepository.save(attendance));
    }

    public AttendanceResponse update(Long id, AttendanceRequest request) {
        Attendance attendance = attendanceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("考勤记录不存在"));

        if (attendanceRepository.existsByStudentIdAndCourseIdAndAttendanceDateAndIdNot(request.studentId(), request.courseId(), request.attendanceDate(), id)) {
            throw new BusinessException("该学生在该日期的课程考勤记录已存在");
        }

        applyRequest(attendance, request);
        return AttendanceResponse.fromEntity(attendanceRepository.save(attendance));
    }

    public void delete(Long id) {
        Attendance attendance = attendanceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("考勤记录不存在"));
        attendanceRepository.delete(attendance);
    }

    private void applyRequest(Attendance attendance, AttendanceRequest request) {
        Student student = studentRepository.findById(request.studentId())
                .orElseThrow(() -> new ResourceNotFoundException("学生不存在"));
        Course course = courseRepository.findById(request.courseId())
                .orElseThrow(() -> new ResourceNotFoundException("课程不存在"));

        attendance.setStudent(student);
        attendance.setCourse(course);
        attendance.setAttendanceDate(request.attendanceDate());
        attendance.setCheckInTime(request.checkInTime());
        attendance.setCheckOutTime(request.checkOutTime());
        attendance.setStatus(AttendanceStatus.valueOf(request.status()));
        attendance.setRemark(trimToNull(request.remark()));
    }

    private String trimToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }
}
