package com.example.sms.server.dto;

import com.example.sms.server.model.Gender;
import com.example.sms.server.model.StudentStatus;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

import java.math.BigDecimal;
import java.time.LocalDate;

public record StudentRequest(
        @NotBlank(message = "学号不能为空") String studentNo,
        @NotBlank(message = "姓名不能为空") String name,
        @NotNull(message = "性别不能为空") Gender gender,
        @NotBlank(message = "年级不能为空") String grade,
        @NotBlank(message = "专业不能为空") String major,
        @NotBlank(message = "班级不能为空") String className,
        @NotBlank(message = "联系电话不能为空") String phone,
        @Email(message = "邮箱格式不正确") String email,
        String address,
        @NotNull(message = "入学日期不能为空") LocalDate enrollmentDate,
        String previousSchool,
        String guardianName,
        String guardianPhone,
        String familyAddress,
        String notes,
        @PositiveOrZero(message = "荣誉数量不能为负数") Integer honorCount,
        @PositiveOrZero(message = "竞赛数量不能为负数") Integer competitionCount,
        @DecimalMin(value = "0.0", message = "消费金额不能为负数") BigDecimal totalConsumption,
        @NotNull(message = "状态不能为空") StudentStatus status
) {
}
