package com.example.sms.server.dto;

import com.example.sms.server.model.Student;

import java.math.BigDecimal;
import java.time.LocalDate;

public record StudentResponse(
        Long id,
        String studentNo,
        String name,
        String gender,
        String grade,
        String major,
        String className,
        String phone,
        String email,
        String address,
        LocalDate enrollmentDate,
        String previousSchool,
        String guardianName,
        String guardianPhone,
        String familyAddress,
        String notes,
        Integer honorCount,
        Integer competitionCount,
        BigDecimal totalConsumption,
        String status
) {
    public static StudentResponse fromEntity(Student student) {
        return new StudentResponse(
                student.getId(),
                student.getStudentNo(),
                student.getName(),
                student.getGender().name(),
                student.getGrade(),
                student.getMajor(),
                student.getClassName(),
                student.getPhone(),
                student.getEmail(),
                student.getAddress(),
                student.getEnrollmentDate(),
                student.getPreviousSchool(),
                student.getGuardianName(),
                student.getGuardianPhone(),
                student.getFamilyAddress(),
                student.getNotes(),
                student.getHonorCount(),
                student.getCompetitionCount(),
                student.getTotalConsumption(),
                student.getStatus().name()
        );
    }
}
