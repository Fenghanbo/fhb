package com.example.sms.server.model;

public enum DevelopmentCategory {
    PRACTICE,
    COMPETITION,
    ACHIEVEMENT,
    HONOR,
    ACTIVITY,
    CONSUMPTION,
    OTHER
}
