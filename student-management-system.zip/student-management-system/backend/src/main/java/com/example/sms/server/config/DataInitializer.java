package com.example.sms.server.config;

import com.example.sms.server.model.AppUser;
import com.example.sms.server.model.ApprovalStatus;
import com.example.sms.server.model.Course;
import com.example.sms.server.model.DevelopmentCategory;
import com.example.sms.server.model.Enrollment;
import com.example.sms.server.model.Gender;
import com.example.sms.server.model.LeaveRequest;
import com.example.sms.server.model.LeaveStatus;
import com.example.sms.server.model.Role;
import com.example.sms.server.model.Student;
import com.example.sms.server.model.StudentDevelopmentRecord;
import com.example.sms.server.model.StudentStatus;
import com.example.sms.server.repository.AppUserRepository;
import com.example.sms.server.repository.CourseRepository;
import com.example.sms.server.repository.EnrollmentRepository;
import com.example.sms.server.repository.LeaveRequestRepository;
import com.example.sms.server.repository.RoleRepository;
import com.example.sms.server.repository.StudentDevelopmentRecordRepository;
import com.example.sms.server.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Configuration
public class DataInitializer {

    @Bean
    public CommandLineRunner seedData(
            RoleRepository roleRepository,
            AppUserRepository appUserRepository,
            StudentRepository studentRepository,
            CourseRepository courseRepository,
            EnrollmentRepository enrollmentRepository,
            LeaveRequestRepository leaveRequestRepository,
            StudentDevelopmentRecordRepository recordRepository,
            PasswordEncoder passwordEncoder,
            @Value("${app.seed.enabled:true}") boolean seedEnabled
    ) {
        return args -> {
            if (!seedEnabled) {
                return;
            }

            Role adminRole = ensureRole(roleRepository, "ADMIN", "系统管理员", "系统设置,用户管理,角色权限,课程管理,学生管理,审批管理,统计分析");
            Role teacherRole = ensureRole(roleRepository, "TEACHER", "任课教师", "课程中心,选课成绩,作业管理,统计查看");
            Role counselorRole = ensureRole(roleRepository, "COUNSELOR", "辅导员", "学生管理,请假审批,成长档案,统计查看");

            ensureUser(appUserRepository, passwordEncoder, adminRole, "admin", "系统管理员", "admin@sms.com", "13800000001");
            ensureUser(appUserRepository, passwordEncoder, teacherRole, "teacher", "张老师", "teacher@sms.com", "13800000002");
            ensureUser(appUserRepository, passwordEncoder, counselorRole, "counselor", "李老师", "counselor@sms.com", "13800000003");

            if (studentRepository.count() == 0) {
                studentRepository.saveAll(List.of(
                        createStudent("2023001", "王小明", Gender.MALE, "2023级", "软件工程", "软工1班", "13812340001", "wangxm@example.com", "上海市浦东新区", LocalDate.of(2023, 9, 1), "上海实验中学", "王建国", "13899990001", "上海市浦东新区海天路1号", "班级学习委员", 2, 1, new BigDecimal("3280.50"), StudentStatus.ACTIVE),
                        createStudent("2023002", "陈雨欣", Gender.FEMALE, "2023级", "数据科学", "数科1班", "13812340002", "chenyx@example.com", "上海市闵行区", LocalDate.of(2023, 9, 1), "闵行中学", "陈丽", "13899990002", "上海市闵行区都会路2号", "积极参加竞赛", 3, 2, new BigDecimal("2950.00"), StudentStatus.ACTIVE),
                        createStudent("2023003", "李晨曦", Gender.FEMALE, "2022级", "人工智能", "智科2班", "13812340003", "licx@example.com", "苏州市工业园区", LocalDate.of(2022, 9, 1), "苏州一中", "李勇", "13899990003", "苏州市工业园区星湖街3号", "校辩论队成员", 1, 1, new BigDecimal("4120.75"), StudentStatus.ACTIVE),
                        createStudent("2022004", "赵志远", Gender.MALE, "2022级", "计算机科学", "计科2班", "13812340004", "zhaozy@example.com", "杭州市西湖区", LocalDate.of(2022, 9, 1), "杭州高级中学", "赵海", "13899990004", "杭州市西湖区文三路4号", "曾获校级奖学金", 2, 0, new BigDecimal("3650.20"), StudentStatus.ACTIVE),
                        createStudent("2021005", "孙悦", Gender.FEMALE, "2021级", "信息管理", "信管1班", "13812340005", "suny@example.com", "南京市鼓楼区", LocalDate.of(2021, 9, 1), "南京外国语学校", "孙霞", "13899990005", "南京市鼓楼区中山北路5号", "正在准备毕业设计", 4, 1, new BigDecimal("4980.00"), StudentStatus.GRADUATED)
                ));
            }

            if (courseRepository.count() == 0) {
                courseRepository.saveAll(List.of(
                        createCourse("SE101", "Java程序设计", "张老师", new BigDecimal("3.0"), "2025-2026-1", "https://example.com/java"),
                        createCourse("DS201", "数据结构", "王老师", new BigDecimal("4.0"), "2025-2026-1", "https://example.com/ds"),
                        createCourse("AI301", "机器学习基础", "刘老师", new BigDecimal("2.0"), "2025-2026-2", "https://example.com/ai")
                ));
            }

            if (enrollmentRepository.count() == 0 && studentRepository.count() > 0 && courseRepository.count() > 0) {
                List<Student> students = studentRepository.findAll();
                List<Course> courses = courseRepository.findAll();
                enrollmentRepository.saveAll(List.of(
                        createEnrollment(students.get(0), courses.get(0), "98.50", "90.00", "88.00", "89.40", 0),
                        createEnrollment(students.get(1), courses.get(0), "97.00", "92.00", "93.00", "92.60", 0),
                        createEnrollment(students.get(2), courses.get(1), "96.00", "89.00", "91.00", "90.20", 1),
                        createEnrollment(students.get(3), courses.get(1), "94.00", "84.00", "87.00", "86.80", 2),
                        createEnrollment(students.get(4), courses.get(2), "99.00", "95.00", "96.00", "95.80", 0)
                ));
            }

            if (leaveRequestRepository.count() == 0 && studentRepository.count() > 0) {
                List<Student> students = studentRepository.findAll();
                leaveRequestRepository.saveAll(List.of(
                        createLeave(students.get(0), "参加省级程序设计竞赛", "杭州", "13812340001", LocalDate.now().plusDays(2), LocalDate.now().plusDays(4), LeaveStatus.PENDING, "王小明", null, null),
                        createLeave(students.get(1), "回家办理证件", "上海", "13812340002", LocalDate.now().minusDays(5), LocalDate.now().minusDays(3), LeaveStatus.APPROVED, "陈雨欣", "李老师", "情况属实，同意请假"),
                        createLeave(students.get(2), "身体不适就医", "苏州", "13812340003", LocalDate.now().minusDays(1), LocalDate.now().plusDays(1), LeaveStatus.REJECTED, "李晨曦", "李老师", "请补充医院证明后重新提交")
                ));
            }

            if (recordRepository.count() == 0 && studentRepository.count() > 0) {
                List<Student> students = studentRepository.findAll();
                recordRepository.saveAll(List.of(
                        createRecord(students.get(0), DevelopmentCategory.PRACTICE, "企业实习周报", "参加校企联合实习并提交阶段成果", "软件工程教研室", "上海张江", LocalDate.now().minusDays(18), LocalDate.now().minusDays(5), new BigDecimal("95.00"), null, ApprovalStatus.APPROVED, "张老师", "实践成果达标"),
                        createRecord(students.get(1), DevelopmentCategory.COMPETITION, "数学建模竞赛", "完成数据建模与答辩展示", "创新创业中心", "闵行校区", LocalDate.now().minusDays(25), LocalDate.now().minusDays(20), new BigDecimal("88.00"), null, ApprovalStatus.SUBMITTED, null, null),
                        createRecord(students.get(2), DevelopmentCategory.HONOR, "校级奖学金", "获得2025学年校级二等奖学金", "学生工作部", "行政楼", LocalDate.now().minusDays(40), LocalDate.now().minusDays(40), new BigDecimal("2.00"), null, ApprovalStatus.APPROVED, "李老师", "荣誉材料审核通过"),
                        createRecord(students.get(3), DevelopmentCategory.ACTIVITY, "校园运动会", "参与男子4x100接力", "体育教学部", "田径场", LocalDate.now().minusDays(12), LocalDate.now().minusDays(12), new BigDecimal("80.00"), null, ApprovalStatus.DRAFT, null, null),
                        createRecord(students.get(4), DevelopmentCategory.CONSUMPTION, "校外实习交通费", "毕业实习期间交通费用登记", "信息管理学院", "南京", LocalDate.now().minusDays(8), LocalDate.now().minusDays(6), null, new BigDecimal("356.50"), ApprovalStatus.APPROVED, "李老师", "费用说明完整")
                ));
            }
        };
    }

    private Role ensureRole(RoleRepository repository, String name, String description, String permissions) {
        return repository.findByNameIgnoreCase(name)
                .map(role -> {
                    role.setDescription(description);
                    role.setPermissions(permissions);
                    return repository.save(role);
                })
                .orElseGet(() -> {
                    Role role = new Role();
                    role.setName(name);
                    role.setDescription(description);
                    role.setPermissions(permissions);
                    return repository.save(role);
                });
    }

    private void ensureUser(AppUserRepository repository, PasswordEncoder passwordEncoder, Role role, String username, String fullName, String email, String phone) {
        repository.findByUsernameIgnoreCase(username).orElseGet(() -> {
            AppUser user = new AppUser();
            user.setUsername(username);
            user.setPasswordHash(passwordEncoder.encode("123456"));
            user.setFullName(fullName);
            user.setEmail(email);
            user.setPhone(phone);
            user.setEnabled(true);
            user.setRole(role);
            return repository.save(user);
        });
    }

    private Student createStudent(String studentNo, String name, Gender gender, String grade, String major, String className,
                                  String phone, String email, String address, LocalDate enrollmentDate, String previousSchool,
                                  String guardianName, String guardianPhone, String familyAddress, String notes, int honorCount,
                                  int competitionCount, BigDecimal totalConsumption, StudentStatus status) {
        Student student = new Student();
        student.setStudentNo(studentNo);
        student.setName(name);
        student.setGender(gender);
        student.setGrade(grade);
        student.setMajor(major);
        student.setClassName(className);
        student.setPhone(phone);
        student.setEmail(email);
        student.setAddress(address);
        student.setEnrollmentDate(enrollmentDate);
        student.setPreviousSchool(previousSchool);
        student.setGuardianName(guardianName);
        student.setGuardianPhone(guardianPhone);
        student.setFamilyAddress(familyAddress);
        student.setNotes(notes);
        student.setHonorCount(honorCount);
        student.setCompetitionCount(competitionCount);
        student.setTotalConsumption(totalConsumption);
        student.setStatus(status);
        return student;
    }

    private Course createCourse(String courseCode, String name, String teacherName, BigDecimal credit, String term, String materialLink) {
        Course course = new Course();
        course.setCourseCode(courseCode);
        course.setName(name);
        course.setTeacherName(teacherName);
        course.setCredit(credit);
        course.setTerm(term);
        course.setMaterialLink(materialLink);
        return course;
    }

    private Enrollment createEnrollment(Student student, Course course, String attendanceRate, String homeworkScore, String finalScore, String totalScore, int absentCount) {
        Enrollment enrollment = new Enrollment();
        enrollment.setStudent(student);
        enrollment.setCourse(course);
        enrollment.setAttendanceRate(new BigDecimal(attendanceRate));
        enrollment.setHomeworkScore(new BigDecimal(homeworkScore));
        enrollment.setFinalScore(new BigDecimal(finalScore));
        enrollment.setTotalScore(new BigDecimal(totalScore));
        enrollment.setAbsentCount(absentCount);
        return enrollment;
    }

    private LeaveRequest createLeave(Student student, String reason, String destination, String contactPhone, LocalDate startDate,
                                     LocalDate endDate, LeaveStatus status, String submitterName, String reviewerName, String reviewComment) {
        LeaveRequest leaveRequest = new LeaveRequest();
        leaveRequest.setStudent(student);
        leaveRequest.setReason(reason);
        leaveRequest.setDestination(destination);
        leaveRequest.setContactPhone(contactPhone);
        leaveRequest.setStartDate(startDate);
        leaveRequest.setEndDate(endDate);
        leaveRequest.setStatus(status);
        leaveRequest.setSubmitterName(submitterName);
        leaveRequest.setReviewerName(reviewerName);
        leaveRequest.setReviewComment(reviewComment);
        leaveRequest.setSubmittedAt(LocalDateTime.now().minusDays(2));
        if (status != LeaveStatus.PENDING) {
            leaveRequest.setReviewedAt(LocalDateTime.now().minusDays(1));
        }
        return leaveRequest;
    }

    private StudentDevelopmentRecord createRecord(Student student, DevelopmentCategory category, String title, String description,
                                                  String organizer, String location, LocalDate startDate, LocalDate endDate,
                                                  BigDecimal score, BigDecimal amount, ApprovalStatus status,
                                                  String reviewerName, String reviewComment) {
        StudentDevelopmentRecord record = new StudentDevelopmentRecord();
        record.setStudent(student);
        record.setCategory(category);
        record.setTitle(title);
        record.setDescription(description);
        record.setOrganizer(organizer);
        record.setLocation(location);
        record.setStartDate(startDate);
        record.setEndDate(endDate);
        record.setScore(score);
        record.setAmount(amount);
        record.setStatus(status);
        record.setReviewerName(reviewerName);
        record.setReviewComment(reviewComment);
        if (status == ApprovalStatus.APPROVED || status == ApprovalStatus.REJECTED) {
            record.setReviewedAt(LocalDateTime.now().minusDays(1));
        }
        return record;
    }
}
