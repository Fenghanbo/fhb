package com.example.sms.server.repository;

import com.example.sms.server.model.Attendance;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AttendanceRepository extends JpaRepository<Attendance, Long> {
    boolean existsByStudentIdAndCourseIdAndAttendanceDate(Long studentId, Long courseId, java.time.LocalDate attendanceDate);
    boolean existsByStudentIdAndCourseIdAndAttendanceDateAndIdNot(Long studentId, Long courseId, java.time.LocalDate attendanceDate, Long id);
    Page<Attendance> findByStudentId(Long studentId, Pageable pageable);
    Page<Attendance> findByCourseId(Long courseId, Pageable pageable);
}
