package com.example.sms.server.repository;

import com.example.sms.server.model.Enrollment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface EnrollmentRepository extends JpaRepository<Enrollment, Long> {

    @Query("select avg(e.totalScore) from Enrollment e")
    Double averageTotalScore();

    @Query("select avg(e.attendanceRate) from Enrollment e")
    Double averageAttendanceRate();

    boolean existsByStudentIdAndCourseId(Long studentId, Long courseId);

    boolean existsByStudentIdAndCourseIdAndIdNot(Long studentId, Long courseId, Long id);
}
