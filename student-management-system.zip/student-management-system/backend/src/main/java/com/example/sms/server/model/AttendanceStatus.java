package com.example.sms.server.model;

public enum AttendanceStatus {
    PRESENT("正常"),
    ABSENT("缺勤"),
    LATE("迟到"),
    EARLY_LEAVE("早退"),
    LEAVE("请假"),
    EXCUSED("补假");

    private final String displayName;

    AttendanceStatus(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
