package com.example.sms.server.dto;

import com.example.sms.server.model.StudentDevelopmentRecord;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

public record StudentDevelopmentRecordResponse(
        Long id,
        Long studentId,
        String studentNo,
        String studentName,
        String category,
        String title,
        String description,
        String organizer,
        String location,
        LocalDate startDate,
        LocalDate endDate,
        BigDecimal score,
        BigDecimal amount,
        String status,
        String reviewerName,
        String reviewComment,
        LocalDateTime reviewedAt
) {
    public static StudentDevelopmentRecordResponse fromEntity(StudentDevelopmentRecord record) {
        return new StudentDevelopmentRecordResponse(
                record.getId(),
                record.getStudent().getId(),
                record.getStudent().getStudentNo(),
                record.getStudent().getName(),
                record.getCategory().name(),
                record.getTitle(),
                record.getDescription(),
                record.getOrganizer(),
                record.getLocation(),
                record.getStartDate(),
                record.getEndDate(),
                record.getScore(),
                record.getAmount(),
                record.getStatus().name(),
                record.getReviewerName(),
                record.getReviewComment(),
                record.getReviewedAt()
        );
    }
}
