package com.example.sms.server.repository;

import com.example.sms.server.model.LeaveRequest;
import com.example.sms.server.model.LeaveStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface LeaveRequestRepository extends JpaRepository<LeaveRequest, Long> {

    long countByStatus(LeaveStatus status);

    List<LeaveRequest> findAllByOrderBySubmittedAtDesc();
}
