package com.example.sms.server.model;

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}
