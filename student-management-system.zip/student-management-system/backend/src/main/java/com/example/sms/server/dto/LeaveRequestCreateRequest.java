package com.example.sms.server.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;

public record LeaveRequestCreateRequest(
        @NotNull(message = "学生ID不能为空") Long studentId,
        @NotBlank(message = "请假原因不能为空") String reason,
        String destination,
        @NotBlank(message = "联系电话不能为空") String contactPhone,
        @NotNull(message = "开始日期不能为空") LocalDate startDate,
        @NotNull(message = "结束日期不能为空") LocalDate endDate,
        @NotBlank(message = "提交人不能为空") String submitterName
) {
}
