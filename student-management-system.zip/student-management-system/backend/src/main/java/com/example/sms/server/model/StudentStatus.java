package com.example.sms.server.model;

public enum StudentStatus {
    ACTIVE,
    LEAVE_OF_ABSENCE,
    GRADUATED
}
