package com.example.sms.server.dto;

import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;
import java.time.LocalTime;

public record AttendanceRequest(
        @NotNull(message = "学生ID不能为空")
        Long studentId,

        @NotNull(message = "课程ID不能为空")
        Long courseId,

        @NotNull(message = "考勤日期不能为空")
        LocalDate attendanceDate,

        LocalTime checkInTime,

        LocalTime checkOutTime,

        @NotNull(message = "考勤状态不能为空")
        String status,

        String remark
) {
}
