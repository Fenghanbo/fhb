package com.example.sms.server.dto;

import com.example.sms.server.model.Attendance;
import com.example.sms.server.model.AttendanceStatus;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public record AttendanceResponse(
        Long id,
        Long studentId,
        String studentNo,
        String studentName,
        Long courseId,
        String courseCode,
        String courseName,
        LocalDate attendanceDate,
        LocalTime checkInTime,
        LocalTime checkOutTime,
        AttendanceStatus status,
        String remark,
        LocalDateTime createdAt,
        LocalDateTime updatedAt
) {
    public static AttendanceResponse fromEntity(Attendance attendance) {
        return new AttendanceResponse(
                attendance.getId(),
                attendance.getStudent().getId(),
                attendance.getStudent().getStudentNo(),
                attendance.getStudent().getName(),
                attendance.getCourse().getId(),
                attendance.getCourse().getCourseCode(),
                attendance.getCourse().getName(),
                attendance.getAttendanceDate(),
                attendance.getCheckInTime(),
                attendance.getCheckOutTime(),
                attendance.getStatus(),
                attendance.getRemark(),
                attendance.getCreatedAt(),
                attendance.getUpdatedAt()
        );
    }
}
