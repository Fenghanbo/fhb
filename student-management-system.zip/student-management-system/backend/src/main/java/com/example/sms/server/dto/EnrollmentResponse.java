package com.example.sms.server.dto;

import com.example.sms.server.model.Enrollment;

import java.math.BigDecimal;

public record EnrollmentResponse(
        Long id,
        Long studentId,
        String studentNo,
        String studentName,
        Long courseId,
        String courseCode,
        String courseName,
        String teacherName,
        String term,
        BigDecimal attendanceRate,
        BigDecimal homeworkScore,
        BigDecimal finalScore,
        BigDecimal totalScore,
        Integer absentCount
) {
    public static EnrollmentResponse fromEntity(Enrollment enrollment) {
        return new EnrollmentResponse(
                enrollment.getId(),
                enrollment.getStudent().getId(),
                enrollment.getStudent().getStudentNo(),
                enrollment.getStudent().getName(),
                enrollment.getCourse().getId(),
                enrollment.getCourse().getCourseCode(),
                enrollment.getCourse().getName(),
                enrollment.getCourse().getTeacherName(),
                enrollment.getCourse().getTerm(),
                enrollment.getAttendanceRate(),
                enrollment.getHomeworkScore(),
                enrollment.getFinalScore(),
                enrollment.getTotalScore(),
                enrollment.getAbsentCount()
        );
    }
}
