package com.example.sms.server.repository;

import com.example.sms.server.model.ApprovalStatus;
import com.example.sms.server.model.DevelopmentCategory;
import com.example.sms.server.model.StudentDevelopmentRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.math.BigDecimal;

public interface StudentDevelopmentRecordRepository extends JpaRepository<StudentDevelopmentRecord, Long> {

    long countByCategory(DevelopmentCategory category);

    long countByStatus(ApprovalStatus status);

    @Query("select coalesce(sum(r.amount), 0) from StudentDevelopmentRecord r where r.category = :category")
    BigDecimal sumAmountByCategory(DevelopmentCategory category);
}
