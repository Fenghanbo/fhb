package com.example.sms.server.service;

import com.example.sms.server.dto.StudentRequest;
import com.example.sms.server.dto.StudentResponse;
import com.example.sms.server.exception.BusinessException;
import com.example.sms.server.exception.ResourceNotFoundException;
import com.example.sms.server.model.Student;
import com.example.sms.server.repository.StudentRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

/**
 * 学生服务类，处理学生相关的业务逻辑
 */
@Service
public class StudentService {

    private final StudentRepository studentRepository;

    /**
     * 构造方法，注入学生仓库
     * @param studentRepository 学生仓库
     */
    public StudentService(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    /**
     * 获取所有学生列表
     * @return 学生列表
     */
    public List<StudentResponse> listStudents() {
        return studentRepository.findAll(Sort.by(Sort.Direction.DESC, "createdAt")).stream()
                .map(StudentResponse::fromEntity)
                .toList();
    }

    /**
     * 分页获取学生列表
     * @param page 页码，从0开始
     * @param size 每页大小
     * @return 分页学生列表
     */
    public Page<StudentResponse> listStudents(int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        return studentRepository.findAll(pageable)
                .map(StudentResponse::fromEntity);
    }

    /**
     * 搜索学生
     * @param keyword 搜索关键词，支持学号、姓名、电话
     * @param page 页码，从0开始
     * @param size 每页大小
     * @return 搜索结果
     */
    public Page<StudentResponse> searchStudents(String keyword, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        return studentRepository.findByStudentNoContainingOrNameContainingOrPhoneContaining(keyword, keyword, keyword, pageable)
                .map(StudentResponse::fromEntity);
    }

    /**
     * 创建学生
     * @param request 学生创建请求
     * @return 创建的学生
     * @throws BusinessException 学号已存在时抛出
     */
    public StudentResponse createStudent(StudentRequest request) {
        if (studentRepository.existsByStudentNo(request.studentNo())) {
            throw new BusinessException("学号已存在");
        }

        Student student = new Student();
        applyRequest(student, request);
        return StudentResponse.fromEntity(studentRepository.save(student));
    }

    /**
     * 更新学生
     * @param id 学生ID
     * @param request 学生更新请求
     * @return 更新后的学生
     * @throws ResourceNotFoundException 学生不存在时抛出
     * @throws BusinessException 学号已存在时抛出
     */
    public StudentResponse updateStudent(Long id, StudentRequest request) {
        Student student = studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("学生不存在"));

        if (studentRepository.existsByStudentNoAndIdNot(request.studentNo(), id)) {
            throw new BusinessException("学号已存在");
        }

        applyRequest(student, request);
        return StudentResponse.fromEntity(studentRepository.save(student));
    }

    /**
     * 删除学生
     * @param id 学生ID
     * @throws ResourceNotFoundException 学生不存在时抛出
     */
    public void deleteStudent(Long id) {
        Student student = studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("学生不存在"));
        studentRepository.delete(student);
    }

    /**
     * 应用请求数据到学生实体
     * @param student 学生实体
     * @param request 学生请求
     */
    private void applyRequest(Student student, StudentRequest request) {
        student.setStudentNo(request.studentNo().trim());
        student.setName(request.name().trim());
        student.setGender(request.gender());
        student.setGrade(request.grade().trim());
        student.setMajor(request.major().trim());
        student.setClassName(request.className().trim());
        student.setPhone(request.phone().trim());
        student.setEmail(trimToNull(request.email()));
        student.setAddress(trimToNull(request.address()));
        student.setEnrollmentDate(request.enrollmentDate());
        student.setPreviousSchool(trimToNull(request.previousSchool()));
        student.setGuardianName(trimToNull(request.guardianName()));
        student.setGuardianPhone(trimToNull(request.guardianPhone()));
        student.setFamilyAddress(trimToNull(request.familyAddress()));
        student.setNotes(trimToNull(request.notes()));
        student.setHonorCount(request.honorCount() == null ? 0 : request.honorCount());
        student.setCompetitionCount(request.competitionCount() == null ? 0 : request.competitionCount());
        student.setTotalConsumption(request.totalConsumption() == null ? BigDecimal.ZERO : request.totalConsumption());
        student.setStatus(request.status());
    }

    /**
     * 字符串.trim()后如果为空则返回null
     * @param value 输入字符串
     * @return 处理后的字符串
     */
    private String trimToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }
}
