package com.example.sms.server.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record UserRequest(
        @NotBlank(message = "用户名不能为空") String username,
        String password,
        @NotBlank(message = "姓名不能为空") String fullName,
        @Email(message = "邮箱格式不正确") String email,
        String phone,
        @NotNull(message = "启用状态不能为空") Boolean enabled,
        @NotNull(message = "角色不能为空") Long roleId
) {
}
