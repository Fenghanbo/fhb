package com.example.sms.server.service;

import com.example.sms.server.dto.UserRequest;
import com.example.sms.server.dto.UserResponse;
import com.example.sms.server.exception.BusinessException;
import com.example.sms.server.exception.ResourceNotFoundException;
import com.example.sms.server.model.AppUser;
import com.example.sms.server.model.Role;
import com.example.sms.server.repository.AppUserRepository;
import com.example.sms.server.repository.RoleRepository;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class UserService {

    private final AppUserRepository appUserRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;

    public UserService(AppUserRepository appUserRepository, RoleRepository roleRepository, PasswordEncoder passwordEncoder) {
        this.appUserRepository = appUserRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Transactional(readOnly = true)
    public List<UserResponse> listUsers() {
        return appUserRepository.findAll(Sort.by(Sort.Direction.DESC, "createdAt")).stream()
                .map(UserResponse::fromEntity)
                .toList();
    }

    public UserResponse create(UserRequest request) {
        String username = request.username().trim();
        if (appUserRepository.existsByUsernameIgnoreCase(username)) {
            throw new BusinessException("用户名已存在");
        }
        if (request.password() == null || request.password().isBlank()) {
            throw new BusinessException("新增用户时密码不能为空");
        }

        Role role = roleRepository.findById(request.roleId())
                .orElseThrow(() -> new ResourceNotFoundException("角色不存在"));

        AppUser user = new AppUser();
        applyRequest(user, request, role, true);
        return UserResponse.fromEntity(appUserRepository.save(user));
    }

    public UserResponse update(Long id, UserRequest request) {
        AppUser user = appUserRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("用户不存在"));

        String username = request.username().trim();
        if (appUserRepository.existsByUsernameIgnoreCaseAndIdNot(username, id)) {
            throw new BusinessException("用户名已存在");
        }

        Role role = roleRepository.findById(request.roleId())
                .orElseThrow(() -> new ResourceNotFoundException("角色不存在"));

        applyRequest(user, request, role, false);
        return UserResponse.fromEntity(appUserRepository.save(user));
    }

    public void delete(Long id) {
        AppUser user = appUserRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("用户不存在"));
        appUserRepository.delete(user);
    }

    private void applyRequest(AppUser user, UserRequest request, Role role, boolean creating) {
        user.setUsername(request.username().trim());
        user.setFullName(request.fullName().trim());
        user.setEmail(trimToNull(request.email()));
        user.setPhone(trimToNull(request.phone()));
        user.setEnabled(request.enabled());
        user.setRole(role);

        if (creating || (request.password() != null && !request.password().isBlank())) {
            user.setPasswordHash(passwordEncoder.encode(request.password().trim()));
        }
    }

    private String trimToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }
}
