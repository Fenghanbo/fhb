package com.example.sms.server.model;

public enum ApprovalStatus {
    DRAFT,
    SUBMITTED,
    APPROVED,
    REJECTED
}
