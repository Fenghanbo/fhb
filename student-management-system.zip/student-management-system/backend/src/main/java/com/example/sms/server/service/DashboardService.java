package com.example.sms.server.service;

import com.example.sms.server.dto.DashboardSummaryResponse;
import com.example.sms.server.model.AttendanceStatus;
import com.example.sms.server.model.Gender;
import com.example.sms.server.model.LeaveStatus;
import com.example.sms.server.model.Student;
import com.example.sms.server.model.StudentStatus;
import com.example.sms.server.repository.AttendanceRepository;
import com.example.sms.server.repository.CourseRepository;
import com.example.sms.server.repository.EnrollmentRepository;
import com.example.sms.server.repository.LeaveRequestRepository;
import com.example.sms.server.repository.StudentRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

@Service
public class DashboardService {

    private final StudentRepository studentRepository;
    private final CourseRepository courseRepository;
    private final EnrollmentRepository enrollmentRepository;
    private final LeaveRequestRepository leaveRequestRepository;
    private final AttendanceRepository attendanceRepository;

    public DashboardService(StudentRepository studentRepository, CourseRepository courseRepository,
                            EnrollmentRepository enrollmentRepository, LeaveRequestRepository leaveRequestRepository,
                            AttendanceRepository attendanceRepository) {
        this.studentRepository = studentRepository;
        this.courseRepository = courseRepository;
        this.enrollmentRepository = enrollmentRepository;
        this.leaveRequestRepository = leaveRequestRepository;
        this.attendanceRepository = attendanceRepository;
    }

    public DashboardSummaryResponse getSummary() {
        List<Student> students = studentRepository.findAll();
        List<com.example.sms.server.model.Attendance> attendances = attendanceRepository.findAll();
        
        long totalHonors = students.stream().mapToLong(Student::getHonorCount).sum();
        long totalCompetitionAwards = students.stream().mapToLong(Student::getCompetitionCount).sum();
        BigDecimal totalConsumption = students.stream()
                .map(Student::getTotalConsumption)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        Double average = enrollmentRepository.averageTotalScore();
        BigDecimal averageScore = average == null
                ? BigDecimal.ZERO
                : BigDecimal.valueOf(average).setScale(2, RoundingMode.HALF_UP);
        
        long totalAttendances = attendances.size();
        long presentCount = attendances.stream()
                .filter(a -> a.getStatus() == AttendanceStatus.PRESENT)
                .count();
        long absentCount = attendances.stream()
                .filter(a -> a.getStatus() == AttendanceStatus.ABSENT)
                .count();
        long lateCount = attendances.stream()
                .filter(a -> a.getStatus() == AttendanceStatus.LATE)
                .count();

        return new DashboardSummaryResponse(
                studentRepository.count(),
                studentRepository.countByStatus(StudentStatus.ACTIVE),
                studentRepository.countByGender(Gender.MALE),
                studentRepository.countByGender(Gender.FEMALE),
                courseRepository.count(),
                enrollmentRepository.count(),
                leaveRequestRepository.countByStatus(LeaveStatus.PENDING),
                leaveRequestRepository.countByStatus(LeaveStatus.APPROVED),
                leaveRequestRepository.countByStatus(LeaveStatus.REJECTED),
                averageScore,
                totalHonors,
                totalCompetitionAwards,
                totalConsumption,
                totalAttendances,
                presentCount,
                absentCount,
                lateCount
        );
    }
}
