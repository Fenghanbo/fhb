package com.example.sms.server.dto;

import com.example.sms.server.model.Role;

public record RoleResponse(
        Long id,
        String name,
        String description,
        String permissions
) {
    public static RoleResponse fromEntity(Role role) {
        return new RoleResponse(
                role.getId(),
                role.getName(),
                role.getDescription(),
                role.getPermissions()
        );
    }
}
