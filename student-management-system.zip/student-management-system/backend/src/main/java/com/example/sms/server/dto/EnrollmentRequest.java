package com.example.sms.server.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

import java.math.BigDecimal;

public record EnrollmentRequest(
        @NotNull(message = "学生不能为空") Long studentId,
        @NotNull(message = "课程不能为空") Long courseId,
        @NotNull(message = "考勤成绩不能为空")
        @DecimalMin(value = "0.0", message = "考勤成绩不能为负数") BigDecimal attendanceRate,
        @NotNull(message = "作业成绩不能为空")
        @DecimalMin(value = "0.0", message = "作业成绩不能为负数") BigDecimal homeworkScore,
        @NotNull(message = "期末成绩不能为空")
        @DecimalMin(value = "0.0", message = "期末成绩不能为负数") BigDecimal finalScore,
        @NotNull(message = "总评成绩不能为空")
        @DecimalMin(value = "0.0", message = "总评成绩不能为负数") BigDecimal totalScore,
        @NotNull(message = "缺勤次数不能为空")
        @PositiveOrZero(message = "缺勤次数不能为负数") Integer absentCount
) {
}
