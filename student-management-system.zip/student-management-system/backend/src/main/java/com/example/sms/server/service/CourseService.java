package com.example.sms.server.service;

import com.example.sms.server.dto.CourseRequest;
import com.example.sms.server.dto.CourseResponse;
import com.example.sms.server.exception.BusinessException;
import com.example.sms.server.exception.ResourceNotFoundException;
import com.example.sms.server.model.Course;
import com.example.sms.server.repository.CourseRepository;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CourseService {

    private final CourseRepository courseRepository;

    public CourseService(CourseRepository courseRepository) {
        this.courseRepository = courseRepository;
    }

    public List<CourseResponse> listCourses() {
        return courseRepository.findAll(Sort.by(Sort.Order.asc("term"), Sort.Order.asc("courseCode"))).stream()
                .map(CourseResponse::fromEntity)
                .toList();
    }

    public CourseResponse create(CourseRequest request) {
        String courseCode = request.courseCode().trim();
        if (courseRepository.existsByCourseCodeIgnoreCase(courseCode)) {
            throw new BusinessException("课程编码已存在");
        }

        Course course = new Course();
        applyRequest(course, request);
        return CourseResponse.fromEntity(courseRepository.save(course));
    }

    public CourseResponse update(Long id, CourseRequest request) {
        Course course = courseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("课程不存在"));
        String courseCode = request.courseCode().trim();
        if (courseRepository.existsByCourseCodeIgnoreCaseAndIdNot(courseCode, id)) {
            throw new BusinessException("课程编码已存在");
        }
        applyRequest(course, request);
        return CourseResponse.fromEntity(courseRepository.save(course));
    }

    public void delete(Long id) {
        Course course = courseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("课程不存在"));
        courseRepository.delete(course);
    }

    private void applyRequest(Course course, CourseRequest request) {
        course.setCourseCode(request.courseCode().trim());
        course.setName(request.name().trim());
        course.setTeacherName(request.teacherName().trim());
        course.setCredit(request.credit());
        course.setTerm(request.term().trim());
        course.setMaterialLink(trimToNull(request.materialLink()));
    }

    private String trimToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }
}
