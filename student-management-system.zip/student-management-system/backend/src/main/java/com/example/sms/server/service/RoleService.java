package com.example.sms.server.service;

import com.example.sms.server.dto.RoleRequest;
import com.example.sms.server.dto.RoleResponse;
import com.example.sms.server.exception.BusinessException;
import com.example.sms.server.exception.ResourceNotFoundException;
import com.example.sms.server.model.Role;
import com.example.sms.server.repository.AppUserRepository;
import com.example.sms.server.repository.RoleRepository;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoleService {

    private final RoleRepository roleRepository;
    private final AppUserRepository appUserRepository;

    public RoleService(RoleRepository roleRepository, AppUserRepository appUserRepository) {
        this.roleRepository = roleRepository;
        this.appUserRepository = appUserRepository;
    }

    public List<RoleResponse> listRoles() {
        return roleRepository.findAll(Sort.by(Sort.Direction.ASC, "name")).stream()
                .map(RoleResponse::fromEntity)
                .toList();
    }

    public RoleResponse create(RoleRequest request) {
        if (roleRepository.existsByNameIgnoreCase(request.name().trim())) {
            throw new BusinessException("角色名称已存在");
        }
        Role role = new Role();
        applyRequest(role, request);
        return RoleResponse.fromEntity(roleRepository.save(role));
    }

    public RoleResponse update(Long id, RoleRequest request) {
        Role role = roleRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("角色不存在"));
        if (roleRepository.existsByNameIgnoreCaseAndIdNot(request.name().trim(), id)) {
            throw new BusinessException("角色名称已存在");
        }
        applyRequest(role, request);
        return RoleResponse.fromEntity(roleRepository.save(role));
    }

    public void delete(Long id) {
        Role role = roleRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("角色不存在"));
        if (appUserRepository.countByRoleId(id) > 0) {
            throw new BusinessException("该角色已被用户使用，无法删除");
        }
        roleRepository.delete(role);
    }

    private void applyRequest(Role role, RoleRequest request) {
        role.setName(request.name().trim());
        role.setDescription(request.description().trim());
        role.setPermissions(trimToNull(request.permissions()));
    }

    private String trimToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }
}
