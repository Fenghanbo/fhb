package com.example.sms.server.dto;

import java.math.BigDecimal;

public record DashboardSummaryResponse(
        long totalStudents,
        long activeStudents,
        long maleStudents,
        long femaleStudents,
        long totalCourses,
        long totalEnrollments,
        long pendingLeaves,
        long approvedLeaves,
        long rejectedLeaves,
        BigDecimal averageScore,
        long totalHonors,
        long totalCompetitionAwards,
        BigDecimal totalConsumption,
        long totalAttendances,
        long presentCount,
        long absentCount,
        long lateCount
) {
}
