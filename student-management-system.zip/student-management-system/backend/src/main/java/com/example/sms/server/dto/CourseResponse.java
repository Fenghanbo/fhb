package com.example.sms.server.dto;

import com.example.sms.server.model.Course;

import java.math.BigDecimal;

public record CourseResponse(
        Long id,
        String courseCode,
        String name,
        String teacherName,
        BigDecimal credit,
        String term,
        String materialLink
) {
    public static CourseResponse fromEntity(Course course) {
        return new CourseResponse(
                course.getId(),
                course.getCourseCode(),
                course.getName(),
                course.getTeacherName(),
                course.getCredit(),
                course.getTerm(),
                course.getMaterialLink()
        );
    }
}
