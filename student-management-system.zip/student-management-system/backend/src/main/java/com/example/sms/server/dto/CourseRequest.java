package com.example.sms.server.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

public record CourseRequest(
        @NotBlank(message = "课程编码不能为空") String courseCode,
        @NotBlank(message = "课程名称不能为空") String name,
        @NotBlank(message = "授课教师不能为空") String teacherName,
        @NotNull(message = "学分不能为空")
        @DecimalMin(value = "0.1", message = "学分必须大于0") BigDecimal credit,
        @NotBlank(message = "学期不能为空") String term,
        String materialLink
) {
}
