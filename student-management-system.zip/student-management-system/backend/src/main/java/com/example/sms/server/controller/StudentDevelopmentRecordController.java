package com.example.sms.server.controller;

import com.example.sms.server.dto.StudentDevelopmentRecordRequest;
import com.example.sms.server.dto.StudentDevelopmentRecordResponse;
import com.example.sms.server.dto.StudentDevelopmentRecordReviewRequest;
import com.example.sms.server.service.StudentDevelopmentRecordService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/records")
public class StudentDevelopmentRecordController {

    private final StudentDevelopmentRecordService recordService;

    public StudentDevelopmentRecordController(StudentDevelopmentRecordService recordService) {
        this.recordService = recordService;
    }

    @GetMapping
    public List<StudentDevelopmentRecordResponse> listRecords() {
        return recordService.listAll();
    }

    @PostMapping
    public StudentDevelopmentRecordResponse create(@Valid @RequestBody StudentDevelopmentRecordRequest request) {
        return recordService.create(request);
    }

    @PutMapping("/{id}")
    public StudentDevelopmentRecordResponse update(@PathVariable Long id, @Valid @RequestBody StudentDevelopmentRecordRequest request) {
        return recordService.update(id, request);
    }

    @PutMapping("/{id}/review")
    public StudentDevelopmentRecordResponse review(@PathVariable Long id, @Valid @RequestBody StudentDevelopmentRecordReviewRequest request) {
        return recordService.review(id, request);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        recordService.delete(id);
    }
}
