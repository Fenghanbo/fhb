@echo off
title Student Management Backend
color 0A

echo.
echo ========================================
echo   Student Management System - Backend
echo ========================================
echo.
echo Starting backend...
echo.

cd /d "%~dp0"
mvnw.cmd spring-boot:run -DskipTests

echo.
echo ========================================
echo   Backend stopped
echo ========================================
echo.
pause
