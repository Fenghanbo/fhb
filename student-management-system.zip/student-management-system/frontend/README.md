# Student Management System - Frontend
学生管理系统 - 前端 (JavaFX)

## 项目说明 / Project Description
这是学生管理系统的前端项目，使用 JavaFX 开发。
This is the frontend project of Student Management System, developed with JavaFX.

## 技术栈 / Tech Stack
- Java 21
- JavaFX 21.0.2
- Maven
- Jackson (JSON处理)

## 运行方式 / How to Run
Windows: 双击 `启动.bat` / Double-click `启动.bat`
或者用 Maven: `mvnw.cmd javafx:run`

## 默认账号 / Default Account
- 用户名 Username: admin
- 密码 Password: 123456

## 注意事项 / Notes
确保后端服务已先启动！
Make sure the backend service is running first!
