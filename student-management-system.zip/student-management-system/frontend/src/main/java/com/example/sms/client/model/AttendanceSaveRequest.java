package com.example.sms.client.model;

import java.time.LocalDate;
import java.time.LocalTime;

public record AttendanceSaveRequest(
        Long studentId,
        Long courseId,
        LocalDate attendanceDate,
        LocalTime checkInTime,
        LocalTime checkOutTime,
        String status,
        String remark
) {
}
