package com.example.sms.client.model;

import java.time.LocalDate;

public record LeaveCreateRequest(
        Long studentId,
        String reason,
        String destination,
        String contactPhone,
        LocalDate startDate,
        LocalDate endDate,
        String submitterName
) {
}
