package com.example.sms.client.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public record DevelopmentRecordSaveRequest(
        Long studentId,
        String category,
        String title,
        String description,
        String organizer,
        String location,
        LocalDate startDate,
        LocalDate endDate,
        BigDecimal score,
        BigDecimal amount,
        String status
) {
}
