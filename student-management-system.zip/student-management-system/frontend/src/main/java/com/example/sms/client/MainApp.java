package com.example.sms.client;

import com.example.sms.client.controller.LoginController;
import com.example.sms.client.controller.MainController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class MainApp extends Application {

    private Stage primaryStage;

    @Override
    public void start(Stage stage) throws IOException {
        this.primaryStage = stage;
        this.primaryStage.setTitle("学生管理系统");
        showLoginView();
        this.primaryStage.show();
    }

    public void showLoginView() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/login-view.fxml"));
        Parent root = loader.load();
        LoginController controller = loader.getController();
        controller.setMainApp(this);

        Scene scene = new Scene(root, 520, 420);
        applyStyles(scene);
        primaryStage.setScene(scene);
    }

    public void showMainView() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/main-view.fxml"));
        Parent root = loader.load();
        MainController controller = loader.getController();
        controller.setMainApp(this);

        Scene scene = new Scene(root, 1360, 860);
        applyStyles(scene);
        primaryStage.setScene(scene);
    }

    private void applyStyles(Scene scene) {
        scene.getStylesheets().add(getClass().getResource("/css/app.css").toExternalForm());
    }

    public static void main(String[] args) {
        launch(args);
    }
}
