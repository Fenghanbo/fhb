package com.example.sms.client.controller;

import com.example.sms.client.AppContext;
import com.example.sms.client.model.CourseItem;
import com.example.sms.client.model.EnrollmentItem;
import com.example.sms.client.model.EnrollmentSaveRequest;
import com.example.sms.client.model.StudentItem;
import com.example.sms.client.util.UiUtils;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.util.StringConverter;

import java.math.BigDecimal;

public class EnrollmentController {

    @FXML
    private Label formTitleLabel;

    @FXML
    private TableView<EnrollmentItem> enrollmentTable;

    @FXML
    private TableColumn<EnrollmentItem, String> enrollmentStudentNoColumn;

    @FXML
    private TableColumn<EnrollmentItem, String> enrollmentStudentNameColumn;

    @FXML
    private TableColumn<EnrollmentItem, String> enrollmentCourseColumn;

    @FXML
    private TableColumn<EnrollmentItem, String> enrollmentTeacherColumn;

    @FXML
    private TableColumn<EnrollmentItem, String> enrollmentTermColumn;

    @FXML
    private TableColumn<EnrollmentItem, String> enrollmentTotalScoreColumn;

    @FXML
    private TableColumn<EnrollmentItem, String> enrollmentAbsentColumn;

    @FXML
    private ComboBox<StudentItem> studentComboBox;

    @FXML
    private ComboBox<CourseItem> courseComboBox;

    @FXML
    private TextField attendanceField;

    @FXML
    private TextField homeworkField;

    @FXML
    private TextField finalScoreField;

    @FXML
    private TextField totalScoreField;

    @FXML
    private TextField absentCountField;

    private final ObservableList<StudentItem> studentItems = FXCollections.observableArrayList();
    private final ObservableList<CourseItem> courseItems = FXCollections.observableArrayList();
    private final ObservableList<EnrollmentItem> enrollmentItems = FXCollections.observableArrayList();
    private Long editingId;

    @FXML
    public void initialize() {
        studentComboBox.setItems(studentItems);
        studentComboBox.setConverter(new StringConverter<>() {
            @Override
            public String toString(StudentItem object) {
                return object == null ? "" : object.studentNo() + " - " + object.name();
            }

            @Override
            public StudentItem fromString(String string) {
                return null;
            }
        });

        courseComboBox.setItems(courseItems);
        courseComboBox.setConverter(new StringConverter<>() {
            @Override
            public String toString(CourseItem object) {
                return object == null ? "" : object.courseCode() + " - " + object.name();
            }

            @Override
            public CourseItem fromString(String string) {
                return null;
            }
        });

        enrollmentStudentNoColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().studentNo()));
        enrollmentStudentNameColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().studentName()));
        enrollmentCourseColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().courseName()));
        enrollmentTeacherColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().teacherName()));
        enrollmentTermColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().term()));
        enrollmentTotalScoreColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().totalScore().toPlainString()));
        enrollmentAbsentColumn.setCellValueFactory(data -> new SimpleStringProperty(String.valueOf(data.getValue().absentCount())));

        enrollmentTable.setItems(enrollmentItems);
        enrollmentTable.getSelectionModel().selectedItemProperty().addListener((obs, oldValue, newValue) -> {
            if (newValue != null) {
                fillForm(newValue);
            }
        });

        loadReferences();
        loadEnrollments();
    }

    @FXML
    private void handleRefresh() {
        loadReferences();
        loadEnrollments();
    }

    @FXML
    private void handleNew() {
        clearForm();
    }

    @FXML
    private void handleSave() {
        try {
            EnrollmentSaveRequest request = buildRequest();
            if (editingId == null) {
                AppContext.apiClient().createEnrollment(request);
                UiUtils.info("保存成功", "选课成绩已新增");
            } else {
                AppContext.apiClient().updateEnrollment(editingId, request);
                UiUtils.info("保存成功", "选课成绩已更新");
            }
            loadEnrollments();
            clearForm();
        } catch (Exception ex) {
            UiUtils.error("保存失败", ex.getMessage());
        }
    }

    @FXML
    private void handleDelete() {
        EnrollmentItem selected = enrollmentTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            UiUtils.error("删除失败", "请先选择要删除的选课记录");
            return;
        }
        if (!UiUtils.confirm("删除确认", "确定删除 " + selected.studentName() + " 的课程记录吗？")) {
            return;
        }
        try {
            AppContext.apiClient().deleteEnrollment(selected.id());
            UiUtils.info("删除成功", "选课记录已删除");
            loadEnrollments();
            clearForm();
        } catch (Exception ex) {
            UiUtils.error("删除失败", ex.getMessage());
        }
    }

    private void loadReferences() {
        try {
            studentItems.setAll(AppContext.apiClient().getStudents());
            courseItems.setAll(AppContext.apiClient().getCourses());
        } catch (Exception ex) {
            UiUtils.error("基础数据加载失败", ex.getMessage());
        }
    }

    private void loadEnrollments() {
        try {
            enrollmentItems.setAll(AppContext.apiClient().getEnrollments());
        } catch (Exception ex) {
            UiUtils.error("选课成绩加载失败", ex.getMessage());
        }
    }

    private void fillForm(EnrollmentItem item) {
        editingId = item.id();
        formTitleLabel.setText("编辑选课成绩");
        studentComboBox.setValue(findStudent(item.studentId()));
        courseComboBox.setValue(findCourse(item.courseId()));
        attendanceField.setText(item.attendanceRate().toPlainString());
        homeworkField.setText(item.homeworkScore().toPlainString());
        finalScoreField.setText(item.finalScore().toPlainString());
        totalScoreField.setText(item.totalScore().toPlainString());
        absentCountField.setText(String.valueOf(item.absentCount()));
    }

    private void clearForm() {
        editingId = null;
        formTitleLabel.setText("新增选课成绩");
        enrollmentTable.getSelectionModel().clearSelection();
        studentComboBox.setValue(null);
        courseComboBox.setValue(null);
        attendanceField.clear();
        homeworkField.clear();
        finalScoreField.clear();
        totalScoreField.clear();
        absentCountField.setText("0");
    }

    private EnrollmentSaveRequest buildRequest() {
        StudentItem student = studentComboBox.getValue();
        CourseItem course = courseComboBox.getValue();
        if (student == null || course == null || attendanceField.getText().isBlank() || homeworkField.getText().isBlank()
                || finalScoreField.getText().isBlank() || totalScoreField.getText().isBlank() || absentCountField.getText().isBlank()) {
            throw new IllegalArgumentException("请先填写完整的选课成绩信息");
        }

        return new EnrollmentSaveRequest(
                student.id(),
                course.id(),
                parseDecimal(attendanceField.getText(), "考勤成绩"),
                parseDecimal(homeworkField.getText(), "作业成绩"),
                parseDecimal(finalScoreField.getText(), "期末成绩"),
                parseDecimal(totalScoreField.getText(), "总评成绩"),
                parseInteger(absentCountField.getText(), "缺勤次数")
        );
    }

    private StudentItem findStudent(Long id) {
        return studentItems.stream()
                .filter(item -> item.id().equals(id))
                .findFirst()
                .orElse(null);
    }

    private CourseItem findCourse(Long id) {
        return courseItems.stream()
                .filter(item -> item.id().equals(id))
                .findFirst()
                .orElse(null);
    }

    private BigDecimal parseDecimal(String value, String fieldName) {
        try {
            return new BigDecimal(value.trim());
        } catch (Exception ex) {
            throw new IllegalArgumentException(fieldName + "格式不正确");
        }
    }

    private Integer parseInteger(String value, String fieldName) {
        try {
            return Integer.parseInt(value.trim());
        } catch (Exception ex) {
            throw new IllegalArgumentException(fieldName + "格式不正确");
        }
    }
}
