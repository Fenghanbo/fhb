package com.example.sms.client.controller;

import com.example.sms.client.AppContext;
import com.example.sms.client.MainApp;
import com.example.sms.client.model.UserSession;
import com.example.sms.client.util.UiUtils;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.io.IOException;

public class LoginController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Label statusLabel;

    private MainApp mainApp;

    @FXML
    public void initialize() {
        usernameField.setText("admin");
        passwordField.setText("123456");
        statusLabel.setText("默认演示账号：admin / 123456");
    }

    @FXML
    private void handleLogin() {
        try {
            UserSession userSession = AppContext.apiClient().login(usernameField.getText().trim(), passwordField.getText());
            AppContext.setCurrentUser(userSession);
            statusLabel.setText("登录成功，正在进入系统...");
            mainApp.showMainView();
        } catch (IOException ex) {
            UiUtils.error("页面加载失败", ex.getMessage());
        } catch (Exception ex) {
            statusLabel.setText(ex.getMessage());
            UiUtils.error("登录失败", ex.getMessage());
        }
    }

    public void setMainApp(MainApp mainApp) {
        this.mainApp = mainApp;
    }
}
