package com.example.sms.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.math.BigDecimal;
import java.time.LocalDate;

@JsonIgnoreProperties(ignoreUnknown = true)
public record StudentItem(
        Long id,
        String studentNo,
        String name,
        String gender,
        String grade,
        String major,
        String className,
        String phone,
        String email,
        String address,
        LocalDate enrollmentDate,
        String previousSchool,
        String guardianName,
        String guardianPhone,
        String familyAddress,
        String notes,
        Integer honorCount,
        Integer competitionCount,
        BigDecimal totalConsumption,
        String status
) {
    @Override
    public String toString() {
        return studentNo + " - " + name;
    }
}
