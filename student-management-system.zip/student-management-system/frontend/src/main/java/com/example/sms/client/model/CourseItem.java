package com.example.sms.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.math.BigDecimal;

@JsonIgnoreProperties(ignoreUnknown = true)
public record CourseItem(
        Long id,
        String courseCode,
        String name,
        String teacherName,
        BigDecimal credit,
        String term,
        String materialLink
) {
    @Override
    public String toString() {
        return courseCode + " - " + name;
    }
}
