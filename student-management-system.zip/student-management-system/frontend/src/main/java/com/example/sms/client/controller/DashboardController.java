package com.example.sms.client.controller;

import com.example.sms.client.AppContext;
import com.example.sms.client.model.DashboardSummary;
import com.example.sms.client.util.UiUtils;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;

public class DashboardController {

    @FXML
    private Label totalStudentsLabel;

    @FXML
    private Label activeStudentsLabel;

    @FXML
    private Label averageScoreLabel;

    @FXML
    private Label totalConsumptionLabel;

    @FXML
    private Label totalAttendancesLabel;

    @FXML
    private Label presentCountLabel;

    @FXML
    private Label absentCountLabel;

    @FXML
    private Label lateCountLabel;

    @FXML
    private PieChart genderPieChart;

    @FXML
    private BarChart<String, Number> businessChart;

    @FXML
    public void initialize() {
        loadSummary();
    }

    @FXML
    private void handleRefresh() {
        loadSummary();
    }

    private void loadSummary() {
        try {
            DashboardSummary summary = AppContext.apiClient().getDashboardSummary();
            totalStudentsLabel.setText(String.valueOf(summary.totalStudents()));
            activeStudentsLabel.setText(String.valueOf(summary.activeStudents()));
            averageScoreLabel.setText(summary.averageScore().toPlainString());
            totalConsumptionLabel.setText("¥ " + summary.totalConsumption().toPlainString());
            totalAttendancesLabel.setText(String.valueOf(summary.totalAttendances()));
            presentCountLabel.setText(String.valueOf(summary.presentCount()));
            absentCountLabel.setText(String.valueOf(summary.absentCount()));
            lateCountLabel.setText(String.valueOf(summary.lateCount()));

            genderPieChart.setData(FXCollections.observableArrayList(
                    new PieChart.Data("男生 " + summary.maleStudents(), summary.maleStudents()),
                    new PieChart.Data("女生 " + summary.femaleStudents(), summary.femaleStudents())
            ));

            XYChart.Series<String, Number> series = new XYChart.Series<>();
            series.getData().add(new XYChart.Data<>("课程数", summary.totalCourses()));
            series.getData().add(new XYChart.Data<>("选课记录", summary.totalEnrollments()));
            series.getData().add(new XYChart.Data<>("待审批", summary.pendingLeaves()));
            series.getData().add(new XYChart.Data<>("已通过", summary.approvedLeaves()));
            series.getData().add(new XYChart.Data<>("已驳回", summary.rejectedLeaves()));
            series.getData().add(new XYChart.Data<>("荣誉数", summary.totalHonors()));
            series.getData().add(new XYChart.Data<>("考勤数", summary.totalAttendances()));
            businessChart.getData().setAll(series);
        } catch (Exception ex) {
            UiUtils.error("加载概览失败", ex.getMessage());
        }
    }
}
