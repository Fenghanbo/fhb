package com.example.sms.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@JsonIgnoreProperties(ignoreUnknown = true)
public record DevelopmentRecordItem(
        Long id,
        Long studentId,
        String studentNo,
        String studentName,
        String category,
        String title,
        String description,
        String organizer,
        String location,
        LocalDate startDate,
        LocalDate endDate,
        BigDecimal score,
        BigDecimal amount,
        String status,
        String reviewerName,
        String reviewComment,
        LocalDateTime reviewedAt
) {
}
