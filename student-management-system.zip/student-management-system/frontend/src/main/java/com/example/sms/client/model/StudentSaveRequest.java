package com.example.sms.client.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public record StudentSaveRequest(
        String studentNo,
        String name,
        String gender,
        String grade,
        String major,
        String className,
        String phone,
        String email,
        String address,
        LocalDate enrollmentDate,
        String previousSchool,
        String guardianName,
        String guardianPhone,
        String familyAddress,
        String notes,
        Integer honorCount,
        Integer competitionCount,
        BigDecimal totalConsumption,
        String status
) {
}
