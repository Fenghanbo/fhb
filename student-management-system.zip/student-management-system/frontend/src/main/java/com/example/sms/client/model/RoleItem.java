package com.example.sms.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record RoleItem(
        Long id,
        String name,
        String description,
        String permissions
) {
    @Override
    public String toString() {
        return name;
    }
}
