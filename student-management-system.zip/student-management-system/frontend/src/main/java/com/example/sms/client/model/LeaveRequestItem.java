package com.example.sms.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.time.LocalDate;
import java.time.LocalDateTime;

@JsonIgnoreProperties(ignoreUnknown = true)
public record LeaveRequestItem(
        Long id,
        Long studentId,
        String studentNo,
        String studentName,
        String reason,
        String destination,
        String contactPhone,
        LocalDate startDate,
        LocalDate endDate,
        String status,
        String submitterName,
        String reviewerName,
        String reviewComment,
        LocalDateTime submittedAt,
        LocalDateTime reviewedAt
) {
}
