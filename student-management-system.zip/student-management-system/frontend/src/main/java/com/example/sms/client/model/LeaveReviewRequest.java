package com.example.sms.client.model;

public record LeaveReviewRequest(
        String status,
        String reviewerName,
        String reviewComment
) {
}
