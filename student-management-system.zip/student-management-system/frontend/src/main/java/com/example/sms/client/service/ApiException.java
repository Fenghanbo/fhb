package com.example.sms.client.service;

public class ApiException extends RuntimeException {

    public ApiException(String message) {
        super(message);
    }
}
