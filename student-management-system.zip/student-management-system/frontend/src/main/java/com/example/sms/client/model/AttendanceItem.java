package com.example.sms.client.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public record AttendanceItem(
        Long id,
        Long studentId,
        String studentNo,
        String studentName,
        Long courseId,
        String courseCode,
        String courseName,
        LocalDate attendanceDate,
        LocalTime checkInTime,
        LocalTime checkOutTime,
        String status,
        String remark,
        LocalDateTime createdAt,
        LocalDateTime updatedAt
) {
}
