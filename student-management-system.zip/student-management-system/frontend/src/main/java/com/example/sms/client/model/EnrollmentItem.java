package com.example.sms.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.math.BigDecimal;

@JsonIgnoreProperties(ignoreUnknown = true)
public record EnrollmentItem(
        Long id,
        Long studentId,
        String studentNo,
        String studentName,
        Long courseId,
        String courseCode,
        String courseName,
        String teacherName,
        String term,
        BigDecimal attendanceRate,
        BigDecimal homeworkScore,
        BigDecimal finalScore,
        BigDecimal totalScore,
        Integer absentCount
) {
}
