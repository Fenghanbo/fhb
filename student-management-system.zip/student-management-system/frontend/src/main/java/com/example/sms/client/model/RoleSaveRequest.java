package com.example.sms.client.model;

public record RoleSaveRequest(
        String name,
        String description,
        String permissions
) {
}
