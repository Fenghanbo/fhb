package com.example.sms.client.controller;

import com.example.sms.client.AppContext;
import com.example.sms.client.model.LeaveCreateRequest;
import com.example.sms.client.model.LeaveRequestItem;
import com.example.sms.client.model.LeaveReviewRequest;
import com.example.sms.client.model.StudentItem;
import com.example.sms.client.util.UiUtils;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.util.StringConverter;

public class LeaveController {

    @FXML
    private TableView<LeaveRequestItem> leaveTable;

    @FXML
    private TableColumn<LeaveRequestItem, String> leaveStudentNoColumn;

    @FXML
    private TableColumn<LeaveRequestItem, String> leaveStudentNameColumn;

    @FXML
    private TableColumn<LeaveRequestItem, String> leaveReasonColumn;

    @FXML
    private TableColumn<LeaveRequestItem, String> leaveStartColumn;

    @FXML
    private TableColumn<LeaveRequestItem, String> leaveEndColumn;

    @FXML
    private TableColumn<LeaveRequestItem, String> leaveStatusColumn;

    @FXML
    private ComboBox<StudentItem> studentComboBox;

    @FXML
    private TextField submitterField;

    @FXML
    private TextField destinationField;

    @FXML
    private TextField contactPhoneField;

    @FXML
    private DatePicker startDatePicker;

    @FXML
    private DatePicker endDatePicker;

    @FXML
    private TextArea reasonArea;

    @FXML
    private Label selectedLeaveLabel;

    @FXML
    private TextField reviewerField;

    @FXML
    private TextArea reviewCommentArea;

    private final ObservableList<StudentItem> studentItems = FXCollections.observableArrayList();
    private final ObservableList<LeaveRequestItem> leaveItems = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        studentComboBox.setItems(studentItems);
        studentComboBox.setConverter(new StringConverter<>() {
            @Override
            public String toString(StudentItem object) {
                return object == null ? "" : object.studentNo() + " - " + object.name();
            }

            @Override
            public StudentItem fromString(String string) {
                return null;
            }
        });

        leaveStudentNoColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().studentNo()));
        leaveStudentNameColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().studentName()));
        leaveReasonColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().reason()));
        leaveStartColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().startDate().toString()));
        leaveEndColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().endDate().toString()));
        leaveStatusColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().status()));

        leaveTable.setItems(leaveItems);
        leaveTable.getSelectionModel().selectedItemProperty().addListener((obs, oldValue, newValue) -> {
            if (newValue != null) {
                selectedLeaveLabel.setText(newValue.studentName() + " | " + newValue.status() + " | " + newValue.reason());
            }
        });

        loadStudents();
        loadLeaves();
    }

    @FXML
    private void handleRefresh() {
        loadStudents();
        loadLeaves();
    }

    @FXML
    private void handleCreateLeave() {
        try {
            StudentItem studentItem = studentComboBox.getValue();
            if (studentItem == null || submitterField.getText().isBlank() || contactPhoneField.getText().isBlank()
                    || startDatePicker.getValue() == null || endDatePicker.getValue() == null || reasonArea.getText().isBlank()) {
                throw new IllegalArgumentException("请先填写完整的请假申请信息");
            }

            LeaveCreateRequest request = new LeaveCreateRequest(
                    studentItem.id(),
                    reasonArea.getText().trim(),
                    emptyToNull(destinationField.getText()),
                    contactPhoneField.getText().trim(),
                    startDatePicker.getValue(),
                    endDatePicker.getValue(),
                    submitterField.getText().trim()
            );
            AppContext.apiClient().createLeaveRequest(request);
            UiUtils.info("提交成功", "请假申请已提交");
            clearCreateForm();
            loadLeaves();
        } catch (Exception ex) {
            UiUtils.error("提交失败", ex.getMessage());
        }
    }

    @FXML
    private void handleApprove() {
        reviewSelected("APPROVED");
    }

    @FXML
    private void handleReject() {
        reviewSelected("REJECTED");
    }

    private void reviewSelected(String status) {
        LeaveRequestItem selected = leaveTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            UiUtils.error("审批失败", "请先选择一条请假记录");
            return;
        }
        if (reviewerField.getText().isBlank()) {
            UiUtils.error("审批失败", "请填写审批人");
            return;
        }
        try {
            AppContext.apiClient().reviewLeaveRequest(selected.id(), new LeaveReviewRequest(
                    status,
                    reviewerField.getText().trim(),
                    emptyToNull(reviewCommentArea.getText())
            ));
            UiUtils.info("审批成功", "请假记录已更新");
            reviewCommentArea.clear();
            loadLeaves();
        } catch (Exception ex) {
            UiUtils.error("审批失败", ex.getMessage());
        }
    }

    private void loadStudents() {
        try {
            studentItems.setAll(AppContext.apiClient().getStudents());
        } catch (Exception ex) {
            UiUtils.error("学生列表加载失败", ex.getMessage());
        }
    }

    private void loadLeaves() {
        try {
            leaveItems.setAll(AppContext.apiClient().getLeaveRequests());
            selectedLeaveLabel.setText("请选择一条请假记录进行审批");
        } catch (Exception ex) {
            UiUtils.error("请假记录加载失败", ex.getMessage());
        }
    }

    private void clearCreateForm() {
        studentComboBox.setValue(null);
        submitterField.clear();
        destinationField.clear();
        contactPhoneField.clear();
        startDatePicker.setValue(null);
        endDatePicker.setValue(null);
        reasonArea.clear();
    }

    private String emptyToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }
}
