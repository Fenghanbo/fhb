package com.example.sms.client.model;

import java.math.BigDecimal;

public record EnrollmentSaveRequest(
        Long studentId,
        Long courseId,
        BigDecimal attendanceRate,
        BigDecimal homeworkScore,
        BigDecimal finalScore,
        BigDecimal totalScore,
        Integer absentCount
) {
}
