package com.example.sms.client.controller;

import com.example.sms.client.AppContext;
import com.example.sms.client.model.AttendanceItem;
import com.example.sms.client.model.AttendanceSaveRequest;
import com.example.sms.client.model.CourseItem;
import com.example.sms.client.model.StudentItem;
import com.example.sms.client.util.UiUtils;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.util.StringConverter;

import java.time.LocalDate;
import java.time.LocalTime;

public class AttendanceController {

    @FXML
    private Label formTitleLabel;

    @FXML
    private TableView<AttendanceItem> attendanceTable;

    @FXML
    private TableColumn<AttendanceItem, String> attendanceStudentNoColumn;

    @FXML
    private TableColumn<AttendanceItem, String> attendanceStudentNameColumn;

    @FXML
    private TableColumn<AttendanceItem, String> attendanceCourseColumn;

    @FXML
    private TableColumn<AttendanceItem, String> attendanceDateColumn;

    @FXML
    private TableColumn<AttendanceItem, String> attendanceStatusColumn;

    @FXML
    private TableColumn<AttendanceItem, String> attendanceCheckInColumn;

    @FXML
    private TableColumn<AttendanceItem, String> attendanceCheckOutColumn;

    @FXML
    private ChoiceBox<StudentItem> studentComboBox;

    @FXML
    private ChoiceBox<CourseItem> courseComboBox;

    @FXML
    private DatePicker attendanceDatePicker;

    @FXML
    private ChoiceBox<String> statusChoiceBox;

    @FXML
    private TextField checkInField;

    @FXML
    private TextField checkOutField;

    @FXML
    private TextArea remarkArea;

    private final ObservableList<StudentItem> studentItems = FXCollections.observableArrayList();
    private final ObservableList<CourseItem> courseItems = FXCollections.observableArrayList();
    private final ObservableList<AttendanceItem> attendanceItems = FXCollections.observableArrayList();
    private Long editingId;

    @FXML
    public void initialize() {
        studentComboBox.setItems(studentItems);
        studentComboBox.setConverter(new StringConverter<>() {
            @Override
            public String toString(StudentItem object) {
                return object == null ? "" : object.studentNo() + " - " + object.name();
            }

            @Override
            public StudentItem fromString(String string) {
                return null;
            }
        });

        courseComboBox.setItems(courseItems);
        courseComboBox.setConverter(new StringConverter<>() {
            @Override
            public String toString(CourseItem object) {
                return object == null ? "" : object.courseCode() + " - " + object.name();
            }

            @Override
            public CourseItem fromString(String string) {
                return null;
            }
        });

        statusChoiceBox.setItems(FXCollections.observableArrayList("PRESENT", "ABSENT", "LATE", "EARLY_LEAVE", "LEAVE", "EXCUSED"));
        statusChoiceBox.setValue("PRESENT");

        attendanceStudentNoColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().studentNo()));
        attendanceStudentNameColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().studentName()));
        attendanceCourseColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().courseName()));
        attendanceDateColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().attendanceDate().toString()));
        attendanceStatusColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().status()));
        attendanceCheckInColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().checkInTime() != null ? data.getValue().checkInTime().toString() : ""));
        attendanceCheckOutColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().checkOutTime() != null ? data.getValue().checkOutTime().toString() : ""));

        attendanceTable.setItems(attendanceItems);
        attendanceTable.getSelectionModel().selectedItemProperty().addListener((obs, oldValue, newValue) -> {
            if (newValue != null) {
                fillForm(newValue);
            }
        });

        loadReferences();
        loadAttendances();
    }

    @FXML
    private void handleRefresh() {
        loadReferences();
        loadAttendances();
    }

    @FXML
    private void handleNew() {
        clearForm();
    }

    @FXML
    private void handleSave() {
        try {
            AttendanceSaveRequest request = buildRequest();
            if (editingId == null) {
                AppContext.apiClient().createAttendance(request);
                UiUtils.info("保存成功", "考勤记录已新增");
            } else {
                AppContext.apiClient().updateAttendance(editingId, request);
                UiUtils.info("保存成功", "考勤记录已更新");
            }
            loadAttendances();
            clearForm();
        } catch (Exception ex) {
            UiUtils.error("保存失败", ex.getMessage());
        }
    }

    @FXML
    private void handleDelete() {
        AttendanceItem selected = attendanceTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            UiUtils.error("删除失败", "请先选择要删除的考勤记录");
            return;
        }
        if (!UiUtils.confirm("删除确认", "确定删除该考勤记录吗？")) {
            return;
        }
        try {
            AppContext.apiClient().deleteAttendance(selected.id());
            UiUtils.info("删除成功", "考勤记录已删除");
            loadAttendances();
            clearForm();
        } catch (Exception ex) {
            UiUtils.error("删除失败", ex.getMessage());
        }
    }

    private void loadReferences() {
        try {
            studentItems.setAll(AppContext.apiClient().getStudents());
            courseItems.setAll(AppContext.apiClient().getCourses());
        } catch (Exception ex) {
            UiUtils.error("基础数据加载失败", ex.getMessage());
        }
    }

    private void loadAttendances() {
        try {
            attendanceItems.setAll(AppContext.apiClient().getAttendances());
        } catch (Exception ex) {
            UiUtils.error("考勤记录加载失败", ex.getMessage());
        }
    }

    private void fillForm(AttendanceItem item) {
        editingId = item.id();
        formTitleLabel.setText("编辑考勤");
        studentComboBox.setValue(findStudent(item.studentId()));
        courseComboBox.setValue(findCourse(item.courseId()));
        attendanceDatePicker.setValue(item.attendanceDate());
        statusChoiceBox.setValue(item.status());
        checkInField.setText(item.checkInTime() != null ? item.checkInTime().toString() : "");
        checkOutField.setText(item.checkOutTime() != null ? item.checkOutTime().toString() : "");
        remarkArea.setText(orEmpty(item.remark()));
    }

    private void clearForm() {
        editingId = null;
        formTitleLabel.setText("新增考勤");
        attendanceTable.getSelectionModel().clearSelection();
        studentComboBox.setValue(null);
        courseComboBox.setValue(null);
        attendanceDatePicker.setValue(LocalDate.now());
        statusChoiceBox.setValue("PRESENT");
        checkInField.clear();
        checkOutField.clear();
        remarkArea.clear();
    }

    private AttendanceSaveRequest buildRequest() {
        StudentItem student = studentComboBox.getValue();
        CourseItem course = courseComboBox.getValue();
        if (student == null || course == null || attendanceDatePicker.getValue() == null || statusChoiceBox.getValue() == null) {
            throw new IllegalArgumentException("请先填写完整的考勤信息");
        }

        return new AttendanceSaveRequest(
                student.id(),
                course.id(),
                attendanceDatePicker.getValue(),
                parseTime(checkInField.getText()),
                parseTime(checkOutField.getText()),
                statusChoiceBox.getValue(),
                emptyToNull(remarkArea.getText())
        );
    }

    private StudentItem findStudent(Long id) {
        return studentItems.stream()
                .filter(item -> item.id().equals(id))
                .findFirst()
                .orElse(null);
    }

    private CourseItem findCourse(Long id) {
        return courseItems.stream()
                .filter(item -> item.id().equals(id))
                .findFirst()
                .orElse(null);
    }

    private LocalTime parseTime(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        try {
            return LocalTime.parse(value.trim());
        } catch (Exception ex) {
            throw new IllegalArgumentException("时间格式不正确，请使用 HH:mm 格式");
        }
    }

    private String emptyToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }

    private String orEmpty(String value) {
        return value == null ? "" : value;
    }
}
