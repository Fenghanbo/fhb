package com.example.sms.client.controller;

import com.example.sms.client.AppContext;
import com.example.sms.client.MainApp;
import com.example.sms.client.model.UserSession;
import com.example.sms.client.util.UiUtils;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

import java.io.IOException;

public class MainController {

    @FXML
    private Label userInfoLabel;

    private MainApp mainApp;

    @FXML
    public void initialize() {
        UserSession currentUser = AppContext.currentUser();
        if (currentUser != null) {
            userInfoLabel.setText(currentUser.fullName() + " | " + currentUser.roleName());
        }
    }

    @FXML
    private void handleLogout() {
        if (!UiUtils.confirm("退出登录", "确定要退出当前登录状态吗？")) {
            return;
        }
        AppContext.clearSession();
        try {
            mainApp.showLoginView();
        } catch (IOException ex) {
            UiUtils.error("退出失败", ex.getMessage());
        }
    }

    public void setMainApp(MainApp mainApp) {
        this.mainApp = mainApp;
    }
}
