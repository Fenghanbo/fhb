package com.example.sms.client.model;

public record UserSaveRequest(
        String username,
        String password,
        String fullName,
        String email,
        String phone,
        Boolean enabled,
        Long roleId
) {
}
