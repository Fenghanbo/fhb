package com.example.sms.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record UserSession(
        Long userId,
        String username,
        String fullName,
        String roleName,
        boolean enabled
) {
}
