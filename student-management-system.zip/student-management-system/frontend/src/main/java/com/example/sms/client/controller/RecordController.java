package com.example.sms.client.controller;

import com.example.sms.client.AppContext;
import com.example.sms.client.model.DevelopmentRecordItem;
import com.example.sms.client.model.DevelopmentRecordReviewRequest;
import com.example.sms.client.model.DevelopmentRecordSaveRequest;
import com.example.sms.client.model.StudentItem;
import com.example.sms.client.util.UiUtils;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.util.StringConverter;

import java.math.BigDecimal;
import java.time.LocalDate;

public class RecordController {

    @FXML
    private TableView<DevelopmentRecordItem> recordTable;

    @FXML
    private TableColumn<DevelopmentRecordItem, String> recordStudentNoColumn;

    @FXML
    private TableColumn<DevelopmentRecordItem, String> recordStudentNameColumn;

    @FXML
    private TableColumn<DevelopmentRecordItem, String> recordCategoryColumn;

    @FXML
    private TableColumn<DevelopmentRecordItem, String> recordTitleColumn;

    @FXML
    private TableColumn<DevelopmentRecordItem, String> recordStatusColumn;

    @FXML
    private TableColumn<DevelopmentRecordItem, String> recordPeriodColumn;

    @FXML
    private Label formTitleLabel;

    @FXML
    private ComboBox<StudentItem> studentComboBox;

    @FXML
    private ComboBox<String> categoryComboBox;

    @FXML
    private TextField titleField;

    @FXML
    private TextField organizerField;

    @FXML
    private TextField locationField;

    @FXML
    private DatePicker startDatePicker;

    @FXML
    private DatePicker endDatePicker;

    @FXML
    private TextField scoreField;

    @FXML
    private TextField amountField;

    @FXML
    private TextArea descriptionArea;

    @FXML
    private Label selectedRecordLabel;

    @FXML
    private TextField reviewerField;

    @FXML
    private TextArea reviewCommentArea;

    private final ObservableList<StudentItem> studentItems = FXCollections.observableArrayList();
    private final ObservableList<DevelopmentRecordItem> recordItems = FXCollections.observableArrayList();
    private Long editingId;

    @FXML
    public void initialize() {
        studentComboBox.setItems(studentItems);
        studentComboBox.setConverter(new StringConverter<>() {
            @Override
            public String toString(StudentItem object) {
                return object == null ? "" : object.studentNo() + " - " + object.name();
            }

            @Override
            public StudentItem fromString(String string) {
                return null;
            }
        });

        categoryComboBox.setItems(FXCollections.observableArrayList(
                "社会实践", "学科竞赛", "科技成果", "荣誉奖励", "日常活动", "消费日志", "其他"
        ));

        recordStudentNoColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().studentNo()));
        recordStudentNameColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().studentName()));
        recordCategoryColumn.setCellValueFactory(data -> new SimpleStringProperty(toCategoryLabel(data.getValue().category())));
        recordTitleColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().title()));
        recordStatusColumn.setCellValueFactory(data -> new SimpleStringProperty(toStatusLabel(data.getValue().status())));
        recordPeriodColumn.setCellValueFactory(data -> new SimpleStringProperty(formatPeriod(data.getValue().startDate(), data.getValue().endDate())));

        recordTable.setItems(recordItems);
        recordTable.getSelectionModel().selectedItemProperty().addListener((obs, oldValue, newValue) -> {
            if (newValue != null) {
                fillForm(newValue);
            }
        });

        loadStudents();
        loadRecords();
        clearForm();
    }

    @FXML
    private void handleRefresh() {
        loadStudents();
        loadRecords();
    }

    @FXML
    private void handleNew() {
        clearForm();
    }

    @FXML
    private void handleSaveDraft() {
        saveRecord("DRAFT");
    }

    @FXML
    private void handleSubmit() {
        saveRecord("SUBMITTED");
    }

    @FXML
    private void handleDelete() {
        DevelopmentRecordItem selected = recordTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            UiUtils.error("删除失败", "请先选择要删除的成长档案记录");
            return;
        }
        if (!UiUtils.confirm("删除确认", "确定删除记录 " + selected.title() + " 吗？")) {
            return;
        }
        try {
            AppContext.apiClient().deleteDevelopmentRecord(selected.id());
            UiUtils.info("删除成功", "成长档案记录已删除");
            loadRecords();
            clearForm();
        } catch (Exception ex) {
            UiUtils.error("删除失败", ex.getMessage());
        }
    }

    @FXML
    private void handleApprove() {
        reviewSelected("APPROVED");
    }

    @FXML
    private void handleReject() {
        reviewSelected("REJECTED");
    }

    private void saveRecord(String status) {
        try {
            DevelopmentRecordSaveRequest request = buildRequest(status);
            if (editingId == null) {
                AppContext.apiClient().createDevelopmentRecord(request);
                UiUtils.info("保存成功", "成长档案记录已新增");
            } else {
                AppContext.apiClient().updateDevelopmentRecord(editingId, request);
                UiUtils.info("保存成功", "成长档案记录已更新");
            }
            loadRecords();
            clearForm();
        } catch (Exception ex) {
            UiUtils.error("保存失败", ex.getMessage());
        }
    }

    private void reviewSelected(String status) {
        DevelopmentRecordItem selected = recordTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            UiUtils.error("审批失败", "请先选择一条成长档案记录");
            return;
        }
        if (reviewerField.getText().isBlank()) {
            UiUtils.error("审批失败", "请填写审批人");
            return;
        }
        try {
            AppContext.apiClient().reviewDevelopmentRecord(selected.id(), new DevelopmentRecordReviewRequest(
                    status,
                    reviewerField.getText().trim(),
                    emptyToNull(reviewCommentArea.getText())
            ));
            UiUtils.info("审批成功", "成长档案审批状态已更新");
            loadRecords();
        } catch (Exception ex) {
            UiUtils.error("审批失败", ex.getMessage());
        }
    }

    private void loadStudents() {
        try {
            studentItems.setAll(AppContext.apiClient().getStudents());
        } catch (Exception ex) {
            UiUtils.error("学生加载失败", ex.getMessage());
        }
    }

    private void loadRecords() {
        try {
            recordItems.setAll(AppContext.apiClient().getDevelopmentRecords());
            if (recordTable.getSelectionModel().getSelectedItem() == null) {
                selectedRecordLabel.setText("请选择一条成长档案记录查看或审批");
            }
        } catch (Exception ex) {
            UiUtils.error("成长档案加载失败", ex.getMessage());
        }
    }

    private void fillForm(DevelopmentRecordItem item) {
        editingId = item.id();
        formTitleLabel.setText("编辑成长档案");
        studentComboBox.setValue(findStudent(item.studentId()));
        categoryComboBox.setValue(toCategoryLabel(item.category()));
        titleField.setText(item.title());
        organizerField.setText(orEmpty(item.organizer()));
        locationField.setText(orEmpty(item.location()));
        startDatePicker.setValue(item.startDate());
        endDatePicker.setValue(item.endDate());
        scoreField.setText(item.score() == null ? "" : item.score().toPlainString());
        amountField.setText(item.amount() == null ? "" : item.amount().toPlainString());
        descriptionArea.setText(orEmpty(item.description()));
        selectedRecordLabel.setText(item.studentName() + " | " + toStatusLabel(item.status()) + " | " + item.title());
        reviewerField.setText(orEmpty(item.reviewerName()));
        reviewCommentArea.setText(orEmpty(item.reviewComment()));
    }

    private void clearForm() {
        editingId = null;
        formTitleLabel.setText("新增成长档案");
        recordTable.getSelectionModel().clearSelection();
        studentComboBox.setValue(null);
        categoryComboBox.setValue("社会实践");
        titleField.clear();
        organizerField.clear();
        locationField.clear();
        startDatePicker.setValue(LocalDate.now());
        endDatePicker.setValue(null);
        scoreField.clear();
        amountField.clear();
        descriptionArea.clear();
        selectedRecordLabel.setText("请选择一条成长档案记录查看或审批");
        reviewerField.clear();
        reviewCommentArea.clear();
    }

    private DevelopmentRecordSaveRequest buildRequest(String status) {
        StudentItem student = studentComboBox.getValue();
        if (student == null || categoryComboBox.getValue() == null || titleField.getText().isBlank() || startDatePicker.getValue() == null) {
            throw new IllegalArgumentException("请先填写完整的成长档案信息");
        }

        return new DevelopmentRecordSaveRequest(
                student.id(),
                toCategoryValue(categoryComboBox.getValue()),
                titleField.getText().trim(),
                emptyToNull(descriptionArea.getText()),
                emptyToNull(organizerField.getText()),
                emptyToNull(locationField.getText()),
                startDatePicker.getValue(),
                endDatePicker.getValue(),
                parseOptionalDecimal(scoreField.getText(), "分值"),
                parseOptionalDecimal(amountField.getText(), "金额"),
                status
        );
    }

    private StudentItem findStudent(Long id) {
        return studentItems.stream()
                .filter(item -> item.id().equals(id))
                .findFirst()
                .orElse(null);
    }

    private BigDecimal parseOptionalDecimal(String value, String fieldName) {
        if (value == null || value.isBlank()) {
            return null;
        }
        try {
            return new BigDecimal(value.trim());
        } catch (Exception ex) {
            throw new IllegalArgumentException(fieldName + "格式不正确");
        }
    }

    private String formatPeriod(LocalDate startDate, LocalDate endDate) {
        return startDate + (endDate == null ? "" : " 至 " + endDate);
    }

    private String emptyToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }

    private String orEmpty(String value) {
        return value == null ? "" : value;
    }

    private String toCategoryValue(String label) {
        return switch (label) {
            case "社会实践" -> "PRACTICE";
            case "学科竞赛" -> "COMPETITION";
            case "科技成果" -> "ACHIEVEMENT";
            case "荣誉奖励" -> "HONOR";
            case "日常活动" -> "ACTIVITY";
            case "消费日志" -> "CONSUMPTION";
            default -> "OTHER";
        };
    }

    private String toCategoryLabel(String value) {
        return switch (value) {
            case "PRACTICE" -> "社会实践";
            case "COMPETITION" -> "学科竞赛";
            case "ACHIEVEMENT" -> "科技成果";
            case "HONOR" -> "荣誉奖励";
            case "ACTIVITY" -> "日常活动";
            case "CONSUMPTION" -> "消费日志";
            default -> "其他";
        };
    }

    private String toStatusLabel(String value) {
        return switch (value) {
            case "DRAFT" -> "草稿";
            case "SUBMITTED" -> "待审批";
            case "APPROVED" -> "已通过";
            case "REJECTED" -> "已驳回";
            default -> value;
        };
    }
}
