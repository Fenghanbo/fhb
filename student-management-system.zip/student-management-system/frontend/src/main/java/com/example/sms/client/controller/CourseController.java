package com.example.sms.client.controller;

import com.example.sms.client.AppContext;
import com.example.sms.client.model.CourseItem;
import com.example.sms.client.model.CourseSaveRequest;
import com.example.sms.client.util.UiUtils;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.math.BigDecimal;

public class CourseController {

    @FXML
    private Label formTitleLabel;

    @FXML
    private TableView<CourseItem> courseTable;

    @FXML
    private TableColumn<CourseItem, String> courseCodeColumn;

    @FXML
    private TableColumn<CourseItem, String> courseNameColumn;

    @FXML
    private TableColumn<CourseItem, String> teacherColumn;

    @FXML
    private TableColumn<CourseItem, String> creditColumn;

    @FXML
    private TableColumn<CourseItem, String> termColumn;

    @FXML
    private TextField courseCodeField;

    @FXML
    private TextField courseNameField;

    @FXML
    private TextField teacherNameField;

    @FXML
    private TextField creditField;

    @FXML
    private TextField termField;

    @FXML
    private TextField materialLinkField;

    private final ObservableList<CourseItem> courseItems = FXCollections.observableArrayList();
    private Long editingId;

    @FXML
    public void initialize() {
        courseCodeColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().courseCode()));
        courseNameColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().name()));
        teacherColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().teacherName()));
        creditColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().credit().toPlainString()));
        termColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().term()));

        courseTable.setItems(courseItems);
        courseTable.getSelectionModel().selectedItemProperty().addListener((obs, oldValue, newValue) -> {
            if (newValue != null) {
                fillForm(newValue);
            }
        });

        loadCourses();
    }

    @FXML
    private void handleRefresh() {
        loadCourses();
    }

    @FXML
    private void handleNew() {
        clearForm();
    }

    @FXML
    private void handleSave() {
        try {
            CourseSaveRequest request = buildRequest();
            if (editingId == null) {
                AppContext.apiClient().createCourse(request);
                UiUtils.info("保存成功", "课程信息已新增");
            } else {
                AppContext.apiClient().updateCourse(editingId, request);
                UiUtils.info("保存成功", "课程信息已更新");
            }
            loadCourses();
            clearForm();
        } catch (Exception ex) {
            UiUtils.error("保存失败", ex.getMessage());
        }
    }

    @FXML
    private void handleDelete() {
        CourseItem selected = courseTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            UiUtils.error("删除失败", "请先选择要删除的课程");
            return;
        }
        if (!UiUtils.confirm("删除确认", "确定删除课程 " + selected.name() + " 吗？")) {
            return;
        }
        try {
            AppContext.apiClient().deleteCourse(selected.id());
            UiUtils.info("删除成功", "课程信息已删除");
            loadCourses();
            clearForm();
        } catch (Exception ex) {
            UiUtils.error("删除失败", ex.getMessage());
        }
    }

    private void loadCourses() {
        try {
            courseItems.setAll(AppContext.apiClient().getCourses());
        } catch (Exception ex) {
            UiUtils.error("课程加载失败", ex.getMessage());
        }
    }

    private void fillForm(CourseItem item) {
        editingId = item.id();
        formTitleLabel.setText("编辑课程");
        courseCodeField.setText(item.courseCode());
        courseNameField.setText(item.name());
        teacherNameField.setText(item.teacherName());
        creditField.setText(item.credit().toPlainString());
        termField.setText(item.term());
        materialLinkField.setText(orEmpty(item.materialLink()));
    }

    private void clearForm() {
        editingId = null;
        formTitleLabel.setText("新增课程");
        courseTable.getSelectionModel().clearSelection();
        courseCodeField.clear();
        courseNameField.clear();
        teacherNameField.clear();
        creditField.clear();
        termField.clear();
        materialLinkField.clear();
    }

    private CourseSaveRequest buildRequest() {
        if (courseCodeField.getText().isBlank() || courseNameField.getText().isBlank()
                || teacherNameField.getText().isBlank() || creditField.getText().isBlank()
                || termField.getText().isBlank()) {
            throw new IllegalArgumentException("请先填写完整的课程信息");
        }

        return new CourseSaveRequest(
                courseCodeField.getText().trim(),
                courseNameField.getText().trim(),
                teacherNameField.getText().trim(),
                parseDecimal(creditField.getText(), "学分"),
                termField.getText().trim(),
                emptyToNull(materialLinkField.getText())
        );
    }

    private BigDecimal parseDecimal(String value, String fieldName) {
        try {
            return new BigDecimal(value.trim());
        } catch (Exception ex) {
            throw new IllegalArgumentException(fieldName + "格式不正确");
        }
    }

    private String emptyToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }

    private String orEmpty(String value) {
        return value == null ? "" : value;
    }
}
