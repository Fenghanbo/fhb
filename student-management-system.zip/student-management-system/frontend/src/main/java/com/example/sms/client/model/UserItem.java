package com.example.sms.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record UserItem(
        Long id,
        String username,
        String fullName,
        String email,
        String phone,
        boolean enabled,
        Long roleId,
        String roleName
) {
}
