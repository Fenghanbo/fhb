package com.example.sms.client.model;

import java.math.BigDecimal;

public record CourseSaveRequest(
        String courseCode,
        String name,
        String teacherName,
        BigDecimal credit,
        String term,
        String materialLink
) {
}
