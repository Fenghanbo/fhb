package com.example.sms.client;

import com.example.sms.client.model.UserSession;
import com.example.sms.client.service.ApiClient;

public final class AppContext {

    private static final String DEFAULT_BASE_URL = "http://localhost:22222";
    private static final ApiClient API_CLIENT = new ApiClient(
            System.getProperty("sms.api.base-url", DEFAULT_BASE_URL)
    );

    private static UserSession currentUser;

    private AppContext() {
    }

    public static ApiClient apiClient() {
        return API_CLIENT;
    }

    public static UserSession currentUser() {
        return currentUser;
    }

    public static void setCurrentUser(UserSession userSession) {
        currentUser = userSession;
    }

    public static void clearSession() {
        currentUser = null;
    }
}
