package com.example.sms.client.controller;

import com.example.sms.client.AppContext;
import com.example.sms.client.model.RoleItem;
import com.example.sms.client.model.RoleSaveRequest;
import com.example.sms.client.model.UserItem;
import com.example.sms.client.model.UserSaveRequest;
import com.example.sms.client.util.UiUtils;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class UserRoleController {

    @FXML
    private TableView<UserItem> userTable;

    @FXML
    private TableColumn<UserItem, String> usernameColumn;

    @FXML
    private TableColumn<UserItem, String> fullNameColumn;

    @FXML
    private TableColumn<UserItem, String> userRoleColumn;

    @FXML
    private TableColumn<UserItem, String> enabledColumn;

    @FXML
    private Label userFormTitleLabel;

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private TextField fullNameField;

    @FXML
    private TextField emailField;

    @FXML
    private TextField phoneField;

    @FXML
    private ComboBox<RoleItem> userRoleComboBox;

    @FXML
    private CheckBox enabledCheckBox;

    @FXML
    private TableView<RoleItem> roleTable;

    @FXML
    private TableColumn<RoleItem, String> roleNameColumn;

    @FXML
    private TableColumn<RoleItem, String> roleDescriptionColumn;

    @FXML
    private Label roleFormTitleLabel;

    @FXML
    private TextField roleNameField;

    @FXML
    private TextField roleDescriptionField;

    @FXML
    private TextArea permissionsArea;

    private final ObservableList<UserItem> userItems = FXCollections.observableArrayList();
    private final ObservableList<RoleItem> roleItems = FXCollections.observableArrayList();
    private Long editingUserId;
    private Long editingRoleId;

    @FXML
    public void initialize() {
        usernameColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().username()));
        fullNameColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().fullName()));
        userRoleColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().roleName()));
        enabledColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().enabled() ? "启用" : "停用"));

        roleNameColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().name()));
        roleDescriptionColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().description()));

        userTable.setItems(userItems);
        roleTable.setItems(roleItems);
        userRoleComboBox.setItems(roleItems);

        userTable.getSelectionModel().selectedItemProperty().addListener((obs, oldValue, newValue) -> {
            if (newValue != null) {
                fillUserForm(newValue);
            }
        });
        roleTable.getSelectionModel().selectedItemProperty().addListener((obs, oldValue, newValue) -> {
            if (newValue != null) {
                fillRoleForm(newValue);
            }
        });

        clearUserForm();
        clearRoleForm();
        loadAll();
    }

    @FXML
    private void handleRefresh() {
        loadAll();
    }

    @FXML
    private void handleNewUser() {
        clearUserForm();
    }

    @FXML
    private void handleSaveUser() {
        try {
            UserSaveRequest request = buildUserRequest();
            if (editingUserId == null) {
                AppContext.apiClient().createUser(request);
                UiUtils.info("保存成功", "系统用户已新增");
            } else {
                AppContext.apiClient().updateUser(editingUserId, request);
                UiUtils.info("保存成功", "系统用户已更新");
            }
            loadUsers();
            clearUserForm();
        } catch (Exception ex) {
            UiUtils.error("保存失败", ex.getMessage());
        }
    }

    @FXML
    private void handleDeleteUser() {
        UserItem selected = userTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            UiUtils.error("删除失败", "请先选择要删除的用户");
            return;
        }
        if (!UiUtils.confirm("删除确认", "确定删除用户 " + selected.username() + " 吗？")) {
            return;
        }
        try {
            AppContext.apiClient().deleteUser(selected.id());
            UiUtils.info("删除成功", "系统用户已删除");
            loadUsers();
            clearUserForm();
        } catch (Exception ex) {
            UiUtils.error("删除失败", ex.getMessage());
        }
    }

    @FXML
    private void handleNewRole() {
        clearRoleForm();
    }

    @FXML
    private void handleSaveRole() {
        try {
            RoleSaveRequest request = buildRoleRequest();
            if (editingRoleId == null) {
                AppContext.apiClient().createRole(request);
                UiUtils.info("保存成功", "角色已新增");
            } else {
                AppContext.apiClient().updateRole(editingRoleId, request);
                UiUtils.info("保存成功", "角色已更新");
            }
            loadRoles();
            loadUsers();
            clearRoleForm();
        } catch (Exception ex) {
            UiUtils.error("保存失败", ex.getMessage());
        }
    }

    @FXML
    private void handleDeleteRole() {
        RoleItem selected = roleTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            UiUtils.error("删除失败", "请先选择要删除的角色");
            return;
        }
        if (!UiUtils.confirm("删除确认", "确定删除角色 " + selected.name() + " 吗？")) {
            return;
        }
        try {
            AppContext.apiClient().deleteRole(selected.id());
            UiUtils.info("删除成功", "角色已删除");
            loadRoles();
            loadUsers();
            clearRoleForm();
        } catch (Exception ex) {
            UiUtils.error("删除失败", ex.getMessage());
        }
    }

    private void loadAll() {
        loadRoles();
        loadUsers();
    }

    private void loadRoles() {
        try {
            roleItems.setAll(AppContext.apiClient().getRoles());
        } catch (Exception ex) {
            UiUtils.error("角色加载失败", ex.getMessage());
        }
    }

    private void loadUsers() {
        try {
            userItems.setAll(AppContext.apiClient().getUsers());
        } catch (Exception ex) {
            UiUtils.error("用户加载失败", ex.getMessage());
        }
    }

    private void fillUserForm(UserItem item) {
        editingUserId = item.id();
        userFormTitleLabel.setText("编辑用户");
        usernameField.setText(item.username());
        passwordField.clear();
        fullNameField.setText(item.fullName());
        emailField.setText(orEmpty(item.email()));
        phoneField.setText(orEmpty(item.phone()));
        enabledCheckBox.setSelected(item.enabled());
        userRoleComboBox.setValue(findRole(item.roleId()));
    }

    private void fillRoleForm(RoleItem item) {
        editingRoleId = item.id();
        roleFormTitleLabel.setText("编辑角色");
        roleNameField.setText(item.name());
        roleDescriptionField.setText(item.description());
        permissionsArea.setText(orEmpty(item.permissions()));
    }

    private void clearUserForm() {
        editingUserId = null;
        userFormTitleLabel.setText("新增用户");
        userTable.getSelectionModel().clearSelection();
        usernameField.clear();
        passwordField.clear();
        fullNameField.clear();
        emailField.clear();
        phoneField.clear();
        enabledCheckBox.setSelected(true);
        userRoleComboBox.setValue(null);
    }

    private void clearRoleForm() {
        editingRoleId = null;
        roleFormTitleLabel.setText("新增角色");
        roleTable.getSelectionModel().clearSelection();
        roleNameField.clear();
        roleDescriptionField.clear();
        permissionsArea.clear();
    }

    private UserSaveRequest buildUserRequest() {
        RoleItem role = userRoleComboBox.getValue();
        if (usernameField.getText().isBlank() || fullNameField.getText().isBlank() || role == null) {
            throw new IllegalArgumentException("请先填写完整的用户信息");
        }
        if (editingUserId == null && passwordField.getText().isBlank()) {
            throw new IllegalArgumentException("新增用户时密码不能为空");
        }
        return new UserSaveRequest(
                usernameField.getText().trim(),
                emptyToNull(passwordField.getText()),
                fullNameField.getText().trim(),
                emptyToNull(emailField.getText()),
                emptyToNull(phoneField.getText()),
                enabledCheckBox.isSelected(),
                role.id()
        );
    }

    private RoleSaveRequest buildRoleRequest() {
        if (roleNameField.getText().isBlank() || roleDescriptionField.getText().isBlank()) {
            throw new IllegalArgumentException("请先填写完整的角色信息");
        }
        return new RoleSaveRequest(
                roleNameField.getText().trim(),
                roleDescriptionField.getText().trim(),
                emptyToNull(permissionsArea.getText())
        );
    }

    private RoleItem findRole(Long roleId) {
        return roleItems.stream()
                .filter(item -> item.id().equals(roleId))
                .findFirst()
                .orElse(null);
    }

    private String emptyToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }

    private String orEmpty(String value) {
        return value == null ? "" : value;
    }
}
