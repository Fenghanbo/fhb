package com.example.sms.client.service;

import com.example.sms.client.model.DashboardSummary;
import com.example.sms.client.model.CourseItem;
import com.example.sms.client.model.CourseSaveRequest;
import com.example.sms.client.model.DevelopmentRecordItem;
import com.example.sms.client.model.DevelopmentRecordReviewRequest;
import com.example.sms.client.model.DevelopmentRecordSaveRequest;
import com.example.sms.client.model.EnrollmentItem;
import com.example.sms.client.model.EnrollmentSaveRequest;
import com.example.sms.client.model.LeaveCreateRequest;
import com.example.sms.client.model.LeaveRequestItem;
import com.example.sms.client.model.LeaveReviewRequest;
import com.example.sms.client.model.RoleItem;
import com.example.sms.client.model.RoleSaveRequest;
import com.example.sms.client.model.StudentItem;
import com.example.sms.client.model.StudentSaveRequest;
import com.example.sms.client.model.UserItem;
import com.example.sms.client.model.UserSaveRequest;
import com.example.sms.client.model.UserSession;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;

public class ApiClient {

    private final String baseUrl;
    private final HttpClient httpClient;
    private final ObjectMapper objectMapper;

    public ApiClient(String baseUrl) {
        this.baseUrl = baseUrl;
        this.httpClient = HttpClient.newHttpClient();
        this.objectMapper = new ObjectMapper();
        this.objectMapper.registerModule(new JavaTimeModule());
        this.objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
    }

    public UserSession login(String username, String password) {
        return send(post("/api/auth/login", new LoginPayload(username, password)), new TypeReference<>() {
        });
    }

    public DashboardSummary getDashboardSummary() {
        return send(get("/api/dashboard/summary"), new TypeReference<>() {
        });
    }

    public List<StudentItem> getStudents() {
        return send(get("/api/students"), new TypeReference<>() {
        });
    }

    public JsonNode getStudentsPage(int page, int size) {
        return send(get("/api/students/page?page=" + page + "&size=" + size), new TypeReference<JsonNode>() {
        });
    }

    public JsonNode searchStudents(String keyword, int page, int size) {
        return send(get("/api/students/search?keyword=" + keyword + "&page=" + page + "&size=" + size), new TypeReference<JsonNode>() {
        });
    }

    public List<StudentItem> searchStudents(String keyword) {
        return send(get("/api/students/search-all?keyword=" + keyword), new TypeReference<>() {
        });
    }

    public StudentItem createStudent(StudentSaveRequest request) {
        return send(post("/api/students", request), new TypeReference<>() {
        });
    }

    public StudentItem updateStudent(Long id, StudentSaveRequest request) {
        return send(put("/api/students/" + id, request), new TypeReference<>() {
        });
    }

    public void deleteStudent(Long id) {
        sendWithoutBody(delete("/api/students/" + id));
    }

    public List<LeaveRequestItem> getLeaveRequests() {
        return send(get("/api/leaves"), new TypeReference<>() {
        });
    }

    public LeaveRequestItem createLeaveRequest(LeaveCreateRequest request) {
        return send(post("/api/leaves", request), new TypeReference<>() {
        });
    }

    public LeaveRequestItem reviewLeaveRequest(Long id, LeaveReviewRequest request) {
        return send(put("/api/leaves/" + id + "/review", request), new TypeReference<>() {
        });
    }

    public List<CourseItem> getCourses() {
        return send(get("/api/courses"), new TypeReference<>() {
        });
    }

    public CourseItem createCourse(CourseSaveRequest request) {
        return send(post("/api/courses", request), new TypeReference<>() {
        });
    }

    public CourseItem updateCourse(Long id, CourseSaveRequest request) {
        return send(put("/api/courses/" + id, request), new TypeReference<>() {
        });
    }

    public void deleteCourse(Long id) {
        sendWithoutBody(delete("/api/courses/" + id));
    }

    public List<EnrollmentItem> getEnrollments() {
        return send(get("/api/enrollments"), new TypeReference<>() {
        });
    }

    public EnrollmentItem createEnrollment(EnrollmentSaveRequest request) {
        return send(post("/api/enrollments", request), new TypeReference<>() {
        });
    }

    public EnrollmentItem updateEnrollment(Long id, EnrollmentSaveRequest request) {
        return send(put("/api/enrollments/" + id, request), new TypeReference<>() {
        });
    }

    public void deleteEnrollment(Long id) {
        sendWithoutBody(delete("/api/enrollments/" + id));
    }

    public List<RoleItem> getRoles() {
        return send(get("/api/roles"), new TypeReference<>() {
        });
    }

    public RoleItem createRole(RoleSaveRequest request) {
        return send(post("/api/roles", request), new TypeReference<>() {
        });
    }

    public RoleItem updateRole(Long id, RoleSaveRequest request) {
        return send(put("/api/roles/" + id, request), new TypeReference<>() {
        });
    }

    public void deleteRole(Long id) {
        sendWithoutBody(delete("/api/roles/" + id));
    }

    public List<UserItem> getUsers() {
        return send(get("/api/users"), new TypeReference<>() {
        });
    }

    public UserItem createUser(UserSaveRequest request) {
        return send(post("/api/users", request), new TypeReference<>() {
        });
    }

    public UserItem updateUser(Long id, UserSaveRequest request) {
        return send(put("/api/users/" + id, request), new TypeReference<>() {
        });
    }

    public void deleteUser(Long id) {
        sendWithoutBody(delete("/api/users/" + id));
    }

    public List<DevelopmentRecordItem> getDevelopmentRecords() {
        return send(get("/api/records"), new TypeReference<>() {
        });
    }

    public DevelopmentRecordItem createDevelopmentRecord(DevelopmentRecordSaveRequest request) {
        return send(post("/api/records", request), new TypeReference<>() {
        });
    }

    public DevelopmentRecordItem updateDevelopmentRecord(Long id, DevelopmentRecordSaveRequest request) {
        return send(put("/api/records/" + id, request), new TypeReference<>() {
        });
    }

    public DevelopmentRecordItem reviewDevelopmentRecord(Long id, DevelopmentRecordReviewRequest request) {
        return send(put("/api/records/" + id + "/review", request), new TypeReference<>() {
        });
    }

    public void deleteDevelopmentRecord(Long id) {
        sendWithoutBody(delete("/api/records/" + id));
    }

    public List<com.example.sms.client.model.AttendanceItem> getAttendances() {
        return send(get("/api/attendances"), new TypeReference<>() {
        });
    }

    public com.example.sms.client.model.AttendanceItem createAttendance(com.example.sms.client.model.AttendanceSaveRequest request) {
        return send(post("/api/attendances", request), new TypeReference<>() {
        });
    }

    public com.example.sms.client.model.AttendanceItem updateAttendance(Long id, com.example.sms.client.model.AttendanceSaveRequest request) {
        return send(put("/api/attendances/" + id, request), new TypeReference<>() {
        });
    }

    public void deleteAttendance(Long id) {
        sendWithoutBody(delete("/api/attendances/" + id));
    }

    private HttpRequest get(String path) {
        return HttpRequest.newBuilder(URI.create(baseUrl + path))
                .header("Accept", "application/json")
                .GET()
                .build();
    }

    private HttpRequest delete(String path) {
        return HttpRequest.newBuilder(URI.create(baseUrl + path))
                .header("Accept", "application/json")
                .DELETE()
                .build();
    }

    private HttpRequest post(String path, Object body) {
        return withJsonBody(path, "POST", body);
    }

    private HttpRequest put(String path, Object body) {
        return withJsonBody(path, "PUT", body);
    }

    private HttpRequest withJsonBody(String path, String method, Object body) {
        try {
            return HttpRequest.newBuilder(URI.create(baseUrl + path))
                    .header("Content-Type", "application/json")
                    .header("Accept", "application/json")
                    .method(method, HttpRequest.BodyPublishers.ofString(objectMapper.writeValueAsString(body)))
                    .build();
        } catch (JsonProcessingException ex) {
            throw new ApiException("请求数据序列化失败: " + ex.getMessage());
        }
    }

    private void sendWithoutBody(HttpRequest request) {
        send(request, false);
    }

    private <T> T send(HttpRequest request, TypeReference<T> typeReference) {
        HttpResponse<String> response = send(request, true);
        try {
            return objectMapper.readValue(response.body(), typeReference);
        } catch (JsonProcessingException ex) {
            throw new ApiException("服务返回数据解析失败: " + ex.getMessage());
        }
    }

    private HttpResponse<String> send(HttpRequest request, boolean expectBody) {
        try {
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() >= 200 && response.statusCode() < 300) {
                if (expectBody || response.body() == null) {
                    return response;
                }
                return response;
            }
            throw new ApiException(extractMessage(response.body(), response.statusCode()));
        } catch (IOException ex) {
            throw new ApiException("无法连接后端服务，请确认 java-server 已启动: " + ex.getMessage());
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new ApiException("请求被中断");
        }
    }

    private String extractMessage(String body, int statusCode) {
        if (body == null || body.isBlank()) {
            return "请求失败，状态码: " + statusCode;
        }
        try {
            JsonNode node = objectMapper.readTree(body);
            if (node.hasNonNull("message")) {
                return node.get("message").asText();
            }
        } catch (JsonProcessingException ignored) {
        }
        return "请求失败，状态码: " + statusCode;
    }

    private record LoginPayload(String username, String password) {
    }
}
