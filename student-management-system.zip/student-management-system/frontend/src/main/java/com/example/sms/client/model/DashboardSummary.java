package com.example.sms.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.math.BigDecimal;

@JsonIgnoreProperties(ignoreUnknown = true)
public record DashboardSummary(
        long totalStudents,
        long activeStudents,
        long maleStudents,
        long femaleStudents,
        long totalCourses,
        long totalEnrollments,
        long pendingLeaves,
        long approvedLeaves,
        long rejectedLeaves,
        BigDecimal averageScore,
        long totalHonors,
        long totalCompetitionAwards,
        BigDecimal totalConsumption,
        long totalAttendances,
        long presentCount,
        long absentCount,
        long lateCount
) {
}
