package com.example.sms.client.controller;

import com.example.sms.client.AppContext;
import com.example.sms.client.model.StudentItem;
import com.example.sms.client.model.StudentSaveRequest;
import com.example.sms.client.util.UiUtils;
import com.fasterxml.jackson.databind.JsonNode;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import javafx.util.Callback;

import java.math.BigDecimal;
import java.util.List;

/**
 * 学生管理控制器，处理学生信息的增删改查、搜索、导出和批量操作
 */
public class StudentController {

    @FXML
    private Label formTitleLabel;

    @FXML
    private TableView<StudentItem> studentTable;

    @FXML
    private TableColumn<StudentItem, String> studentNoColumn;

    @FXML
    private TableColumn<StudentItem, String> nameColumn;

    @FXML
    private TableColumn<StudentItem, String> genderColumn;

    @FXML
    private TableColumn<StudentItem, String> majorColumn;

    @FXML
    private TableColumn<StudentItem, String> classColumn;

    @FXML
    private TableColumn<StudentItem, String> statusColumn;

    @FXML
    private TextField studentNoField;

    @FXML
    private TextField nameField;

    @FXML
    private ChoiceBox<String> genderChoice;

    @FXML
    private TextField gradeField;

    @FXML
    private TextField majorField;

    @FXML
    private TextField classNameField;

    @FXML
    private TextField phoneField;

    @FXML
    private TextField emailField;

    @FXML
    private TextField addressField;

    @FXML
    private DatePicker enrollmentDatePicker;

    @FXML
    private TextField previousSchoolField;

    @FXML
    private TextField guardianNameField;

    @FXML
    private TextField guardianPhoneField;

    @FXML
    private TextField familyAddressField;

    @FXML
    private TextField honorCountField;

    @FXML
    private TextField competitionCountField;

    @FXML
    private TextField totalConsumptionField;

    @FXML
    private ChoiceBox<String> statusChoice;

    @FXML
    private TableColumn<StudentItem, Boolean> selectColumn;

    @FXML
    private TextArea notesArea;

    @FXML
    private TextField searchField;

    private final ObservableList<StudentItem> studentItems = FXCollections.observableArrayList();
    private final ObservableList<StudentItem> selectedItems = FXCollections.observableArrayList();
    private Long editingId;

    @FXML
    public void initialize() {
        genderChoice.setItems(FXCollections.observableArrayList("MALE", "FEMALE", "OTHER"));
        statusChoice.setItems(FXCollections.observableArrayList("ACTIVE", "LEAVE_OF_ABSENCE", "GRADUATED"));
        genderChoice.setValue("MALE");
        statusChoice.setValue("ACTIVE");

        // 设置复选框列
        selectColumn.setCellValueFactory(cellData -> {
            StudentItem item = cellData.getValue();
            SimpleBooleanProperty property = new SimpleBooleanProperty(selectedItems.contains(item));
            property.addListener((obs, oldValue, newValue) -> {
                if (newValue) {
                    selectedItems.add(item);
                } else {
                    selectedItems.remove(item);
                }
            });
            return property;
        });

        selectColumn.setCellFactory(new Callback<>() {
            @Override
            public TableCell<StudentItem, Boolean> call(TableColumn<StudentItem, Boolean> param) {
                return new TableCell<>() {
                    private final CheckBox checkBox = new CheckBox();

                    {
                        checkBox.setOnAction(event -> {
                            StudentItem item = getTableView().getItems().get(getIndex());
                            if (checkBox.isSelected()) {
                                selectedItems.add(item);
                            } else {
                                selectedItems.remove(item);
                            }
                        });
                    }

                    @Override
                    protected void updateItem(Boolean item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            checkBox.setSelected(item);
                            setGraphic(checkBox);
                            setAlignment(javafx.geometry.Pos.CENTER);
                        }
                    }
                };
            }
        });

        studentNoColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().studentNo()));
        nameColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().name()));
        genderColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().gender()));
        majorColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().major()));
        classColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().className()));
        statusColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().status()));

        studentTable.setItems(studentItems);
        studentTable.getSelectionModel().selectedItemProperty().addListener((obs, oldValue, newValue) -> {
            if (newValue != null) {
                fillForm(newValue);
            }
        });

        loadStudents();
    }

    @FXML
    private void handleRefresh() {
        loadStudents();
    }

    @FXML
    private void handleNew() {
        clearForm();
    }

    @FXML
    private void handleSave() {
        try {
            StudentSaveRequest request = buildRequest();
            if (editingId == null) {
                AppContext.apiClient().createStudent(request);
                UiUtils.info("保存成功", "学生信息已新增");
            } else {
                AppContext.apiClient().updateStudent(editingId, request);
                UiUtils.info("保存成功", "学生信息已更新");
            }
            loadStudents();
            clearForm();
        } catch (Exception ex) {
            UiUtils.error("保存失败", ex.getMessage());
        }
    }

    @FXML
    private void handleDelete() {
        StudentItem selected = studentTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            UiUtils.error("删除失败", "请先选择要删除的学生");
            return;
        }
        if (!UiUtils.confirm("删除确认", "确定删除学生 " + selected.name() + " 吗？")) {
            return;
        }
        try {
            AppContext.apiClient().deleteStudent(selected.id());
            UiUtils.info("删除成功", "学生信息已删除");
            loadStudents();
            clearForm();
        } catch (Exception ex) {
            UiUtils.error("删除失败", ex.getMessage());
        }
    }



    @FXML
    private void handleSearch() {
        String keyword = searchField.getText().trim();
        if (keyword.isEmpty()) {
            loadStudents();
        } else {
            try {
                List<StudentItem> allStudents = AppContext.apiClient().getStudents();
                List<StudentItem> filtered = allStudents.stream()
                        .filter(s -> s.studentNo().contains(keyword) 
                                || s.name().contains(keyword)
                                || s.major().contains(keyword)
                                || s.className().contains(keyword))
                        .toList();
                studentItems.setAll(filtered);
            } catch (Exception ex) {
                UiUtils.error("搜索失败", ex.getMessage());
            }
        }
    }

    @FXML
    private void handleReset() {
        searchField.clear();
        loadStudents();
    }

    @FXML
    private void handleExport() {
        try {
            // 创建导出文件
            java.io.File file = new java.io.File("students_export.csv");
            java.io.FileWriter writer = new java.io.FileWriter(file);
            
            // 写入CSV表头
            writer.write("学号,姓名,性别,年级,专业,班级,电话,邮箱,地址,入学日期,毕业学校,监护人,监护电话,家庭住址,荣誉次数,竞赛次数,消费金额,状态,备注\n");
            
            // 写入学生数据
            for (StudentItem item : studentItems) {
                writer.write(String.join(",", 
                    item.studentNo(),
                    item.name(),
                    item.gender(),
                    item.grade(),
                    item.major(),
                    item.className(),
                    item.phone(),
                    orEmpty(item.email()),
                    orEmpty(item.address()),
                    item.enrollmentDate().toString(),
                    orEmpty(item.previousSchool()),
                    orEmpty(item.guardianName()),
                    orEmpty(item.guardianPhone()),
                    orEmpty(item.familyAddress()),
                    String.valueOf(item.honorCount()),
                    String.valueOf(item.competitionCount()),
                    item.totalConsumption().toPlainString(),
                    item.status(),
                    orEmpty(item.notes())
                ) + "\n");
            }
            
            writer.close();
            UiUtils.info("导出成功", "学生信息已导出到 " + file.getAbsolutePath());
        } catch (Exception ex) {
            UiUtils.error("导出失败", ex.getMessage());
        }
    }

    @FXML
    private void handleBatchDelete() {
        if (selectedItems.isEmpty()) {
            UiUtils.error("批量删除失败", "请先选择要删除的学生");
            return;
        }
        if (!UiUtils.confirm("批量删除确认", "确定删除选中的 " + selectedItems.size() + " 个学生吗？")) {
            return;
        }
        try {
            for (StudentItem item : selectedItems) {
                AppContext.apiClient().deleteStudent(item.id());
            }
            UiUtils.info("批量删除成功", "已删除 " + selectedItems.size() + " 个学生");
            loadStudents();
            clearForm();
        } catch (Exception ex) {
            UiUtils.error("批量删除失败", ex.getMessage());
        }
    }

    private void loadStudents() {
        try {
            studentItems.setAll(AppContext.apiClient().getStudents());
        } catch (Exception ex) {
            UiUtils.error("加载失败", ex.getMessage());
        }
    }

    private void loadStudentsPage(int page) {
        try {
            JsonNode response;
            if (currentKeyword != null) {
                response = AppContext.apiClient().searchStudents(currentKeyword, page, pageSize);
            } else {
                response = AppContext.apiClient().getStudentsPage(page, pageSize);
            }
            JsonNode content = response.get("content");
            int totalElements = response.get("totalElements").asInt();
            totalPages = response.get("totalPages").asInt();
            currentPage = response.get("number").asInt();

            studentItems.clear();
            selectedItems.clear();
            if (content.isArray()) {
                for (JsonNode item : content) {
                    Long id = item.get("id").asLong();
                    String studentNo = item.get("studentNo").asText();
                    String name = item.get("name").asText();
                    String gender = item.get("gender").asText();
                    String grade = item.get("grade").asText();
                    String major = item.get("major").asText();
                    String className = item.get("className").asText();
                    String phone = item.get("phone").asText();
                    String email = item.has("email") && !item.get("email").isNull() ? item.get("email").asText() : null;
                    String address = item.has("address") && !item.get("address").isNull() ? item.get("address").asText() : null;
                    java.time.LocalDate enrollmentDate = java.time.LocalDate.parse(item.get("enrollmentDate").asText());
                    String previousSchool = item.has("previousSchool") && !item.get("previousSchool").isNull() ? item.get("previousSchool").asText() : null;
                    String guardianName = item.has("guardianName") && !item.get("guardianName").isNull() ? item.get("guardianName").asText() : null;
                    String guardianPhone = item.has("guardianPhone") && !item.get("guardianPhone").isNull() ? item.get("guardianPhone").asText() : null;
                    String familyAddress = item.has("familyAddress") && !item.get("familyAddress").isNull() ? item.get("familyAddress").asText() : null;
                    String notes = item.has("notes") && !item.get("notes").isNull() ? item.get("notes").asText() : null;
                    int honorCount = item.get("honorCount").asInt();
                    int competitionCount = item.get("competitionCount").asInt();
                    java.math.BigDecimal totalConsumption = new java.math.BigDecimal(item.get("totalConsumption").asText());
                    String status = item.get("status").asText();

                    studentItems.add(new StudentItem(
                            id, studentNo, name, gender, grade, major, className, phone, email, address,
                            enrollmentDate, previousSchool, guardianName, guardianPhone, familyAddress, notes,
                            honorCount, competitionCount, totalConsumption, status
                    ));
                }
            }


        } catch (Exception ex) {
            UiUtils.error("加载失败", ex.getMessage());
        }
    }

    private void fillForm(StudentItem item) {
        editingId = item.id();
        formTitleLabel.setText("编辑学生");
        studentNoField.setText(item.studentNo());
        nameField.setText(item.name());
        genderChoice.setValue(item.gender());
        gradeField.setText(item.grade());
        majorField.setText(item.major());
        classNameField.setText(item.className());
        phoneField.setText(item.phone());
        emailField.setText(orEmpty(item.email()));
        addressField.setText(orEmpty(item.address()));
        enrollmentDatePicker.setValue(item.enrollmentDate());
        previousSchoolField.setText(orEmpty(item.previousSchool()));
        guardianNameField.setText(orEmpty(item.guardianName()));
        guardianPhoneField.setText(orEmpty(item.guardianPhone()));
        familyAddressField.setText(orEmpty(item.familyAddress()));
        honorCountField.setText(String.valueOf(item.honorCount()));
        competitionCountField.setText(String.valueOf(item.competitionCount()));
        totalConsumptionField.setText(item.totalConsumption().toPlainString());
        statusChoice.setValue(item.status());
        notesArea.setText(orEmpty(item.notes()));
    }

    private void clearForm() {
        editingId = null;
        formTitleLabel.setText("新增学生");
        studentTable.getSelectionModel().clearSelection();
        studentNoField.clear();
        nameField.clear();
        genderChoice.setValue("MALE");
        gradeField.clear();
        majorField.clear();
        classNameField.clear();
        phoneField.clear();
        emailField.clear();
        addressField.clear();
        enrollmentDatePicker.setValue(null);
        previousSchoolField.clear();
        guardianNameField.clear();
        guardianPhoneField.clear();
        familyAddressField.clear();
        honorCountField.setText("0");
        competitionCountField.setText("0");
        totalConsumptionField.setText("0");
        statusChoice.setValue("ACTIVE");
        notesArea.clear();
    }

    private StudentSaveRequest buildRequest() {
        if (studentNoField.getText().isBlank() || nameField.getText().isBlank() || gradeField.getText().isBlank()
                || majorField.getText().isBlank() || classNameField.getText().isBlank() || phoneField.getText().isBlank()
                || enrollmentDatePicker.getValue() == null) {
            throw new IllegalArgumentException("请先填写完整的必填信息");
        }

        return new StudentSaveRequest(
                studentNoField.getText().trim(),
                nameField.getText().trim(),
                genderChoice.getValue(),
                gradeField.getText().trim(),
                majorField.getText().trim(),
                classNameField.getText().trim(),
                phoneField.getText().trim(),
                emptyToNull(emailField.getText()),
                emptyToNull(addressField.getText()),
                enrollmentDatePicker.getValue(),
                emptyToNull(previousSchoolField.getText()),
                emptyToNull(guardianNameField.getText()),
                emptyToNull(guardianPhoneField.getText()),
                emptyToNull(familyAddressField.getText()),
                emptyToNull(notesArea.getText()),
                parseInteger(honorCountField.getText(), "荣誉数量"),
                parseInteger(competitionCountField.getText(), "竞赛数量"),
                parseDecimal(totalConsumptionField.getText(), "消费金额"),
                statusChoice.getValue()
        );
    }

    private Integer parseInteger(String value, String fieldName) {
        try {
            return Integer.parseInt(value.trim());
        } catch (Exception ex) {
            throw new IllegalArgumentException(fieldName + "格式不正确");
        }
    }

    private BigDecimal parseDecimal(String value, String fieldName) {
        try {
            return new BigDecimal(value.trim());
        } catch (Exception ex) {
            throw new IllegalArgumentException(fieldName + "格式不正确");
        }
    }

    private String emptyToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }

    private String orEmpty(String value) {
        return value == null ? "" : value;
    }
}
