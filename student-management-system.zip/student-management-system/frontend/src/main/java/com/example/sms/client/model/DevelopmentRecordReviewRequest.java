package com.example.sms.client.model;

public record DevelopmentRecordReviewRequest(
        String status,
        String reviewerName,
        String reviewComment
) {
}
