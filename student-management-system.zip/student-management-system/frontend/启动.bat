@echo off
title Student Management Frontend
color 0B

echo.
echo ========================================
echo   Student Management System - Frontend
echo ========================================
echo.
echo Starting frontend...
echo.

cd /d "%~dp0"
mvnw.cmd javafx:run -DskipTests

echo.
echo ========================================
echo   Frontend stopped
echo ========================================
echo.
pause
